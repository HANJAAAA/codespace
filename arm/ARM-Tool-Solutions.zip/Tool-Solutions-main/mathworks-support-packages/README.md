# MathWorks Support Packages for Arm Tools
Here is a repository of the support packages, for various MATLAB versions, made for Arm tools/boards to enable better integration between MATLAB, Simulink, and Arm products. 


For more information see the following pages:
- [Arm Fast Models Support Package](https://www.mathworks.com/products/connections/product_detail/arm-fast-models.html)
- [Arm Compiler Support Package](https://www.mathworks.com/products/connections/product_detail/arm-compiler.html)
