/*
 * Copyright (c) 2020 Arm Limited. All rights reserved.
 */
#include "external_counter.h"

