## Cortex-M55 software example

This is a small hello-world example to show some of the new features of the Cortex-M55.

Make sure to use Arm Compiler 6.14 or newer.

For a complete example with a Cortex-M55 Fast Model system and software look at the [example in the cortex-m55 directory.](https://github.com/ARM-software/Tool-Solutions/tree/master/fast-models-examples/cortex-m55)
