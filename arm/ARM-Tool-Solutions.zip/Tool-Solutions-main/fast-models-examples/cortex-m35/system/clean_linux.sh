#!/bin/sh
#
# clean.sh -- Clean the SystemC Peripheral example
#
# Copyright 2015-2022 ARM Limited.
# All rights reserved.
#

# select the version of gcc you use
#make rel_gcc49_64_clean
#make rel_gcc64_64_clean
#make rel_gcc73_64_clean
make rel_gcc93_64_clean
