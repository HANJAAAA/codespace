# Inspect the image to see all of the architectures 
# Make sure to change to your own hub account

docker buildx imagetools inspect jasonrandrews/c-hello-world
