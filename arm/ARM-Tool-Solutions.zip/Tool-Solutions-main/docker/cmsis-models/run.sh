docker run --network host -it cmsis-models /bin/bash
