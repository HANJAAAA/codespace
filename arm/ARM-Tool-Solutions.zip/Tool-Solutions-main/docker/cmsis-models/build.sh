docker build -t cmsis-models  -f Dockerfile .

