#!/bin/bash

[ -f DS500-BN-00026-r5p0-16rel0.tgz ] || wget https://developer.arm.com/-/media/Files/downloads/compiler/DS500-BN-00026-r5p0-16rel0.tgz

