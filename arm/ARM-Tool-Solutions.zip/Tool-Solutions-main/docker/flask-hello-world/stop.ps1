# stop and remove the containers, errors can be ignored if they don't exist
docker stop flask-amd64 flask-arm64 flask-armv7 flask-native