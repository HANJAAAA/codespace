# inspect the image to see all of the architectures 
# make sure to change to your own hub account
docker buildx imagetools inspect jasonrandrews/flask-hello-world