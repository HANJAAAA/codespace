
## Table of Contents 
Here is a list of the contents with short descriptions:

### hikey960-ubuntu
Scripts to build everything needed to install Ubuntu on the [HiKey 960](https://www.96boards.org/product/hikey960/).

### rock960-linux
Script to install OpenCL on the [Rock 960](https://www.96boards.org/product/rock960/).
