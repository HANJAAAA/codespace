/*
 * TLMX: tlmx_has_get_protocol_types.h - A utility header
 *
 * Copyright 2020 arm Limited.
 * All rights reserved.
 */

#ifndef TLMX_HAS_GET_PROTOCOL_TYPES_H
#define TLMX_HAS_GET_PROTOCOL_TYPES_H

/**
 * @file        tlmx_has_get_protocol_types.h
 *
 * @brief       A utility header to deal with non standard conformant
 *              Accelera specific socket interface - get_protocol_types.
 */

/* Includes */
#include <utility>
#include <typeindex>

/* Namespaces */

/**
 * @brief       TLMX namespace.
 */
namespace tlmx {
/**
 * @brief       Wrapper around tlm_base_(intiator|target)_socket
 *
 * @note        @c tlmx_has_get_protocol_types is a wrapper around BASE type.
 *              If BASE type doesn't declare get_protocol_types as a
 *              virtual member function, tlmx_has_get_protocol_types
 *              is a mere wrapper of BASE.
 *              If BASE type declares get_protocol_types as a virtual
 *              member, tlmx_has_get_protocol_types implements the (pure)
 *              virtual function.
 *              There are base classes which inherit from tlm_base_socket_if
 *              class in TLM.  tlm_base_socket_if declares tlmx_has_get_protocol_types
 *              as a pure virtual in Accelera systemc version 2.3.2 and above
 *              but doesn't declare this function in earlier versions and also
 *              not found in the SystemC IEEE 1666-2011 standard.
 *              The following SFINAE based approach helps to deal with this
 *              in a systemc implementation agnostic way.
 *
 * @param       BASE could be
 *              @c tlm::tlm_base_initiator_socket or
 *              @c tlm::tlm_base_target_socket
 * @param       TYPES protocol traits class; defaults to
 *              @c tlm::tlm_base_protocol_types.
 */
template <typename BASE, typename TYPES, typename = void>
struct tlmx_has_get_protocol_types : public BASE {
    using BASE::BASE;
};

template <typename BASE, typename TYPES>
struct tlmx_has_get_protocol_types<
    BASE, TYPES,
    decltype(std::declval<BASE>().get_protocol_types(), void())>
    : public BASE {
    using BASE::BASE;

    /**
     * @brief       Returns the protocol type
     */
    std::type_index get_protocol_types() const override {
        return (std::type_index(typeid(TYPES)));
    }
};
} /* namespace tlmx */

#endif /* defined(TLMX_HAS_GET_PROTOCOL_TYPES_H) */
