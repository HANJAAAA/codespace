/*
 * AMBA-PV: amba_pv_atomic_utils.h - AMBA-PV far atomics utility functions
 *
 * Copyright 2023 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_ATOMIC_UTILS__H
#define AMBA_PV_ATOMIC_UTILS__H

/**
 * @file        amba_pv_atomic_utils.h
 *
 * @brief       AMBA-PV far atomics utility functions
 */

/* Includes */
#include "amba_pv_atomic.h"
#include "amba_pv_atomic_subop_impl.h"

#include <systemc>

#include <algorithm>
#include <cstring>
#include <type_traits>
#include <vector>
#ifdef _MSC_VER
#include <stdlib.h> // byteswap
#endif

/* Namespaces */

/**
 * @brief       AMBA-PV namespace.
 */
namespace amba_pv {

// Provide platform specific byte swapping functions (16, 32 and 64 bits), only
// MSVC, GCC and Clang are supported.
// Starting from C++23, std::byteswap is available which can replace this marco.
#ifdef _MSC_VER
#define byteswap_16 _byteswap_ushort
#define byteswap_32 _byteswap_ulong
#define byteswap_64 _byteswap_uint64
#elif defined(__GNUC__) || defined(__clang__)
#define byteswap_16 __builtin_bswap16
#define byteswap_32 __builtin_bswap32
#define byteswap_64 __builtin_bswap64
#else
#error "Unsupported Compiler"
#endif

/**
 * @brief       Swaps the bytes on a block of memory based on a specified size.
 *
 * @param       data pointer to the beginning of the data to be byte swapped.
 * @param       size size of the data in bytes. Sizes [1, 2, 4, 8] are
 *              supported.
 *
 * @note        It is used by AtomicStore and AtomicLoad to handle endianness
 *              conversion.
 */
inline void
swap_bytes(unsigned char* const data, const size_t size) {
    switch (size) {
        case 1:
            // No action needed for single byte data
            break;
        case 2: {
            uint16_t* d = reinterpret_cast<uint16_t*>(data);
            *d          = byteswap_16(*d);
        } break;
        case 4: {
            uint32_t* d = reinterpret_cast<uint32_t*>(data);
            *d          = byteswap_32(*d);
        } break;
        case 8: {
            uint64_t* d = reinterpret_cast<uint64_t*>(data);
            *d          = byteswap_64(*d);
        } break;
        default:
            SC_REPORT_ERROR("",
                            "swap_bytes(): invalid size");
            break;
    }
}

/**
 * @brief       An utility class that offers the implementation of executing an
 *              atomic transaction. The class contains the implementation of
 *              AtomicStore, AtomicLoad, AtomicSwap and AtomicCompare.
 */
class amba_pv_atomic_utils {

    public:
        static void atomic_store(unsigned char* memory,
                                 unsigned char* data,
                                 size_t size,
                                 amba_pv_atomic_subop_t subop,
                                 amba_pv_atomic_endianness_t endianness);
        static void atomic_load(unsigned char* memory,
                                unsigned char* data,
                                size_t size,
                                amba_pv_atomic_subop_t subop,
                                amba_pv_atomic_endianness_t endianness);
        static void atomic_swap(unsigned char* memory,
                                unsigned char* data,
                                size_t size);
        static bool atomic_compare(unsigned char* memory,
                                   unsigned char* data,
                                   size_t size,
                                   bool compare_first);

    /* Implementation */
    private:
    /* Helpers */
        template<typename SUBOP_IMPL>
        static void do_subop(unsigned char* memory,
                             unsigned char* data,
                             size_t size,
                             amba_pv_atomic_endianness_t endianness);
};

/* Functions */

/**
 * @brief       Completes an atomic store transaction. Memory value is updated
 *              according to the atomic subop and incoming data.
 *
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer. It must point to an array of
 *              @a size bytes.
 * @param       size transaction size in bytes as one of [1, 2, 4, 8]. The
 *              transaction size must be less than or equal to the value
 *              returned by get_bus_width_bytes().
 * @param       subop operation type of the atomic transaction.
 * @param       endianness endianness of the atomic operation. If enabled,
 *              memory value and incoming data is interpreted in big endian
 *              order.
 */
inline void
amba_pv_atomic_utils::atomic_store(unsigned char* const memory,
                                   unsigned char* const data,
                                   const size_t size,
                                   const amba_pv_atomic_subop_t subop,
                                   const amba_pv_atomic_endianness_t endianness) {
    sc_assert(memory && data);

    // Check atomic signals
    amba_pv_atomic request(AMBA_PV_ATOMICSTORE, subop, endianness);
    if (! request.is_atomic_request_valid(size)) {
        SC_REPORT_ERROR("amba_pv_atomic_utils",
                        "atomic_store(): invalid atomic request");
    }

    // Execute subop and write result to memory
    using namespace atomic_subop_impl;
    switch (subop) {
        case AMBA_PV_ATOMIC_ADD:
            do_subop<do_add>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_BIT_CLEAR:
            do_subop<do_bit_clear>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_EXCLUSIVE_OR:
            do_subop<do_xor>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_BIT_SET:
            do_subop<do_bit_set>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_SIGNED_MAX:
            do_subop<do_signed_max>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_SIGNED_MIN:
            do_subop<do_signed_min>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_UNSIGNED_MAX:
            do_subop<do_unsigned_max>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_UNSIGNED_MIN:
            do_subop<do_unsigned_min>(memory, data, size, endianness);
            break;
    }
}

/**
 * @brief       Completes an atomic load transaction. Memory value is updated
 *              according to the atomic subop and incoming data, the original
 * memory value is then returned to the data pointer.
 *
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer. It must point to an array of
 *              @a size bytes. The array should initially contain the sending
 *              data, then the original data at the address before the atomic
 *              operation is returned to the array.
 * @param       size transaction size in bytes as one of [1, 2, 4, 8]. The
 *              transaction size must be less than or equal to the value
 *              returned by get_bus_width_bytes().
 * @param       subop operation type of the atomic transaction.
 * @param       endianness endianness of the atomic operation. If enabled,
 *              memory value and incoming data is interpreted in big endian
 *              order.
 */
inline void
amba_pv_atomic_utils::atomic_load(unsigned char* const memory,
                                  unsigned char* const data,
                                  const size_t size,
                                  const amba_pv_atomic_subop_t subop,
                                  const amba_pv_atomic_endianness_t endianness) {
    sc_assert(memory && data);

    // Check atomic signals
    amba_pv_atomic request(AMBA_PV_ATOMICLOAD, subop, endianness);
    if (! request.is_atomic_request_valid(size)) {
        SC_REPORT_ERROR("amba_pv_atomic_utils",
                        "atomic_load(): invalid atomic request");
    }

    // Back up memory value
    std::vector<unsigned char> prior_value(memory, memory + size);

    // Execute subop and write result to memory
    using namespace atomic_subop_impl;
    switch (subop) {
        case AMBA_PV_ATOMIC_ADD:
            do_subop<do_add>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_BIT_CLEAR:
            do_subop<do_bit_clear>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_EXCLUSIVE_OR:
            do_subop<do_xor>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_BIT_SET:
            do_subop<do_bit_set>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_SIGNED_MAX:
            do_subop<do_signed_max>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_SIGNED_MIN:
            do_subop<do_signed_min>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_UNSIGNED_MAX:
            do_subop<do_unsigned_max>(memory, data, size, endianness);
            break;
        case AMBA_PV_ATOMIC_UNSIGNED_MIN:
            do_subop<do_unsigned_min>(memory, data, size, endianness);
            break;
    }

    // Return data to initiator
    std::copy_n(prior_value.begin(), size, data);
}

/**
 * @brief       Completes an atomic swap transaction. Memory value is updated as
 *              the incoming data, the original memory value is then returned to
 *              the data pointer.
 *
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer. It must point to an array of
 *              @a size bytes. The array should initially contain the sending
 *              data, then the original data at the address before the atomic
 *              operation is returned to the array.
 * @param       size transaction size in bytes as one of [1, 2, 4, 8]. The
 *              transaction size must be less than or equal to the value
 *              returned by get_bus_width_bytes().
 */
inline void
amba_pv_atomic_utils::atomic_swap(unsigned char* const memory,
                                  unsigned char* const data,
                                  const size_t size) {
    sc_assert(memory && data);

    // Check atomic signals
    amba_pv_atomic request(AMBA_PV_ATOMICSWAP);
    if (! request.is_atomic_request_valid(size)) {
        SC_REPORT_ERROR("amba_pv_atomic_utils",
                        "atomic_swap(): invalid atomic request");
    }

    std::vector<unsigned char> prior_value(memory, memory + size);

    std::memcpy(memory, data, size);
    std::copy_n(prior_value.begin(), size, data);
}

/**
 * @brief       Completes an atomic compare transaction. Initiator sends out
 *              comparing and swapping data. Memory value is checked against the
 *              comparing data, if they are equal, the memory value is updated
 *              as the swapping data. The original memory value is then returned
 *              to the data pointer.
 *
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer. It must point to an array of
 *              @a size bytes. The array should initially comprise of
 *              comparing and swapping data, after the transaction, the
 *              original data at the address before the atomic operation is
 *              returned to the array.
 * @param       size transaction size in bytes as one of [2, 4, 8, 16, 32].
 *              It accommodates both comparing and swapping data, with
 *              each occupying half the size. The transaction size must be
 *              less than or equal to the value returned by
 *              set_bus_width_bytes().
 * @param       compare_first Comparing data is sent before swapping data.
 *
 * @return      @c true if memory value is swapped, @c false otherwise.
 *
 * @note        Transaction data pointer points to an array comprising of
 *              comparing and swapping data, with their order determined by the
 *              transaction address. Comparing data is sent first if the
 *              address points to the lower half of the transaction (i.e.
 *              lowest address byte); swapping data is sent first if the
 *              address points to the upper half of the transaction (i.e.
 *              lowest address plus half the @a *size*).
 *
 * @note        The original data at the address is returned to @a data
 *              pointer starting from the lowest byte. The returning size is
 *              half the sending @a size.
 */
inline bool
amba_pv_atomic_utils::atomic_compare(unsigned char* const memory,
                                     unsigned char* const data,
                                     const size_t size,
                                     const bool compare_first) {
    sc_assert(memory && data);

    // Check atomic signals
    amba_pv_atomic request(AMBA_PV_ATOMICCOMPARE);
    if (! request.is_atomic_request_valid(size)) {
        SC_REPORT_ERROR("amba_pv_atomic_utils",
                        "atomic_compare(): invalid atomic request");
    }

    // Size of either comparing or swapping data
    // Incoming data comprises of both comparing and swapping data of equal size
    // See the AXI specification A7.4.3 for more information.
    const size_t data_size = size / 2;

    // Back up memory value
    std::vector<unsigned char> prior_value(memory, memory + data_size);

    // Determine comparing and swapping data location
    unsigned char* compare_data = compare_first ? data : data + data_size;
    unsigned char* swap_data    = compare_first ? data + data_size : data;

    const bool do_swap = (std::memcmp(memory, compare_data, data_size) == 0);
    if (do_swap) {
        std::memcpy(memory, swap_data, data_size);
    }

    // Return data to initiator
    std::copy_n(prior_value.begin(), data_size, data);

    return do_swap;
}

/**
 * @brief       Completes an in-place atomic operation on memory.
 *
 * @tparam      SUBOP_IMPL functor that implements the atomic operation type.
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer. It must point to an array of
 *              @a size bytes.
 * @param       size transaction size in bytes as one of [1, 2, 4, 8].
 * @param       endianness endianness of the atomic operation. If enabled,
 *              memory value and incoming data is interpreted in big endian
 *              order.
 */
template<typename SUBOP_IMPL>
inline void
amba_pv_atomic_utils::do_subop(unsigned char* const memory,
                               unsigned char* const data,
                               const size_t size,
                               const amba_pv_atomic_endianness_t endianness) {
    std::vector<unsigned char> tmp(memory, memory + size);

    // Convert big endian data to little endian
    if (endianness == AMBA_PV_BIG_ENDIAN) {
        swap_bytes(tmp.data(), size);
        swap_bytes(data, size);
    }

    constexpr bool is_signed = SUBOP_IMPL::is_signed;
    switch (size) {
        case 1: {
            using T =
                typename std::conditional<is_signed, int8_t, uint8_t>::type;
            SUBOP_IMPL().template operator()<T>(tmp.data(), data);
        } break;
        case 2: {
            using T =
                typename std::conditional<is_signed, int16_t, uint16_t>::type;
            SUBOP_IMPL().template operator()<T>(tmp.data(), data);
        } break;
        case 4: {
            using T =
                typename std::conditional<is_signed, int32_t, uint32_t>::type;
            SUBOP_IMPL().template operator()<T>(tmp.data(), data);
        } break;
        case 8: {
            using T =
                typename std::conditional<is_signed, int64_t, uint64_t>::type;
            SUBOP_IMPL().template operator()<T>(tmp.data(), data);
        } break;
        default:
            SC_REPORT_ERROR("amba_pv_atomic_utils", "do_subop(): invalid size");
            break;
    }

    // Convert little endian data back to big endian
    if (endianness == AMBA_PV_BIG_ENDIAN) {
        swap_bytes(tmp.data(), size);
        swap_bytes(data, size);
    }

    std::copy_n(tmp.begin(), size, memory);
}

} /* namespace amba_pv */

#endif /* defined(AMBA_PV_ATOMIC_UTILS__H) */