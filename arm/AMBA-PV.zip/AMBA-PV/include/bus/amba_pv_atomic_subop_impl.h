/*
 * AMBA-PV: amba_pv_atomic_subop_impl.h - AMBA-PV far atomics operation type implemention
 *
 * Copyright 2023 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_ATOMIC_SUBOP_IMPL__H
#define AMBA_PV_ATOMIC_SUBOP_IMPL__H

/**
 * @file        amba_pv_atomic_subop_impl.h
 *
 * @brief       AMBA-PV far atomics operation type implemention
 */

/* Includes */
#include <systemc>

#include <type_traits>

/* Namespaces */

/**
 * @brief       AMBA-PV namespace.
 */
namespace amba_pv {

/**
 * @brief       AMBA-PV atomic operation type implementation namespace.
 */
namespace atomic_subop_impl {

/**
 * @brief       A functor for in-place addition operation.
 */
struct do_add {
    static constexpr bool is_signed = false;
    template<typename T>
    void operator()(unsigned char* memory, unsigned char* data) const;
};

/**
 * @brief       A functor for in-place bit clear operation.
 */
struct do_bit_clear {
    static constexpr bool is_signed = false;
    template<typename T>
    void operator()(unsigned char* memory, unsigned char* data) const;
};

/**
 * @brief       A functor for in-place exclusive or operation.
 */
struct do_xor {
    static constexpr bool is_signed = false;
    template<typename T>
    void operator()(unsigned char* memory, unsigned char* data) const;
};

/**
 * @brief       A functor for in-place bit set operation.
 */
struct do_bit_set {
    static constexpr bool is_signed = false;
    template<typename T>
    void operator()(unsigned char* memory, unsigned char* data) const;
};

/**
 * @brief       A functor for in-place signed max operation.
 */
struct do_signed_max {
    static constexpr bool is_signed = true;
    template<typename T>
    void operator()(unsigned char* memory, unsigned char* data) const;
};

/**
 * @brief       A functor for in-place signed min operation.
 */
struct do_signed_min {
    static constexpr bool is_signed = true;
    template<typename T>
    void operator()(unsigned char* memory, unsigned char* data) const;
};

/**
 * @brief       A functor for in-place unsigned max operation.
 */
struct do_unsigned_max {
    static constexpr bool is_signed = false;
    template<typename T>
    void operator()(unsigned char* memory, unsigned char* data) const;
};

/**
 * @brief       A functor for in-place unsigned min operation.
 */
struct do_unsigned_min {
    static constexpr bool is_signed = false;
    template<typename T>
    void operator()(unsigned char* memory, unsigned char* data) const;
};

/* Functions */

/**
 * @brief       Completes an addition operation.
 *
 * @tparam      T integer type that aligns with the size of the atomic
 *              transaction.
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer.
 */
template<typename T>
inline void
do_add::operator()(unsigned char* const memory,
                   unsigned char* const data) const {
    static_assert(std::is_signed<T>::value == is_signed,
                  "Unsigned type required.");
    T* m = reinterpret_cast<T*>(memory);
    T* d = reinterpret_cast<T*>(data);
    *m   = *m + *d;
}

/**
 * @brief       Completes a bit clear operation.
 *
 * @tparam      T integer type that aligns with the size of the atomic
 *              transaction.
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer.
 */
template<typename T>
inline void
do_bit_clear::operator()(unsigned char* const memory,
                         unsigned char* const data) const {
    static_assert(std::is_signed<T>::value == is_signed,
                  "Unsigned type required.");
    T* m = reinterpret_cast<T*>(memory);
    T* d = reinterpret_cast<T*>(data);
    *m   = *m & ~*d;
}

/**
 * @brief       Completes an exclusive or operation.
 *
 * @tparam      T integer type that aligns with the size of the atomic
 *              transaction.
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer.
 */
template<typename T>
inline void
do_xor::operator()(unsigned char* const memory,
                   unsigned char* const data) const {
    static_assert(std::is_signed<T>::value == is_signed,
                  "Unsigned type required.");
    T* m = reinterpret_cast<T*>(memory);
    T* d = reinterpret_cast<T*>(data);
    *m   = *m ^ *d;
}

/**
 * @brief       Completes a bit set operation.
 *
 * @tparam      T integer type that aligns with the size of the atomic
 *              transaction.
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer.
 */
template<typename T>
inline void
do_bit_set::operator()(unsigned char* const memory,
                       unsigned char* const data) const {
    static_assert(std::is_signed<T>::value == is_signed,
                  "Unsigned type required.");
    T* m = reinterpret_cast<T*>(memory);
    T* d = reinterpret_cast<T*>(data);
    *m   = *m | *d;
}

/**
 * @brief       Completes a signed max operation.
 *
 * @tparam      T integer type that aligns with the size of the atomic
 *              transaction.
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer.
 */
template<typename T>
inline void
do_signed_max::operator()(unsigned char* const memory,
                          unsigned char* const data) const {
    static_assert(std::is_signed<T>::value == is_signed,
                  "Signed type required.");
    T* m = reinterpret_cast<T*>(memory);
    T* d = reinterpret_cast<T*>(data);
    *m   = std::max(*m, *d);
}

/**
 * @brief       Completes a signed min operation.
 *
 * @tparam      T integer type that aligns with the size of the atomic
 *              transaction.
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer.
 */
template<typename T>
inline void
do_signed_min::operator()(unsigned char* const memory,
                          unsigned char* const data) const {
    static_assert(std::is_signed<T>::value == is_signed,
                  "Signed type required.");
    T* m = reinterpret_cast<T*>(memory);
    T* d = reinterpret_cast<T*>(data);
    *m   = std::min(*m, *d);
}

/**
 * @brief       Completes an unsigned max operation.
 *
 * @tparam      T integer type that aligns with the size of the atomic
 *              transaction.
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer.
 */
template<typename T>
inline void
do_unsigned_max::operator()(unsigned char* const memory,
                            unsigned char* const data) const {
    static_assert(std::is_signed<T>::value == is_signed,
                  "Unsigned type required.");
    T* m = reinterpret_cast<T*>(memory);
    T* d = reinterpret_cast<T*>(data);
    *m   = std::max(*m, *d);
}

/**
 * @brief       Completes an unsigned min operation.
 *
 * @tparam      T integer type that aligns with the size of the atomic
 *              transaction.
 * @param       memory data pointer pointing to the target address in the
 *              memory.
 * @param       data transaction data pointer.
 */
template<typename T>
inline void
do_unsigned_min::operator()(unsigned char* const memory,
                            unsigned char* const data) const {
    static_assert(std::is_signed<T>::value == is_signed,
                  "Unsigned type required.");
    T* m = reinterpret_cast<T*>(memory);
    T* d = reinterpret_cast<T*>(data);
    *m   = std::min(*m, *d);
}

} /* namespace atomic_subop_impl */
} /* namespace amba_pv */

#endif /* defined(AMBA_PV_ATOMIC_SUBOP_IMPL__H) */