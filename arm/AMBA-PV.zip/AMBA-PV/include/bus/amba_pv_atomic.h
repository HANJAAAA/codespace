/*
 * AMBA-PV: amba_pv_atomic.h - AMBA-PV additional information for atomic transaction.
 *
 * Copyright 2023 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_ATOMIC__H
#define AMBA_PV_ATOMIC__H

/**
 * @file        amba_pv_atomic.h
 *
 * @brief       AMBA-PV additional information for atomic transaction.
 */

/* Namespaces */

/**
 * @brief       AMBA-PV namespace.
 */
namespace amba_pv {

/**
 * @brief     Atomic transaction type.
 *
 * The atomic transaction type indicates the type of an atomic transaction.
 * For AtomicStore and AtomicLoad, their signals also incorporate endianness and
 * atomic operation type, which are independently indicated by
 * amba_pv_atomic_subop_t and amba_pv_atomic_endianness_t.
 *
 * The bit representation of this type partially matches the AXI AWATOP[5:0] AMBA5
 * signals. For non-atomic operation, AtomicSwap and AtomicCompare, the bits
 * fully represent the signals; for AtomicStore and AtomicLoad, the bits only
 * represent the AWATOP[5:4] signals.
 *
 * @note        AXI AWATOP[5:0] signals:
 *              0b000000     Non-atomic operation
 *              0b01exxx     AtomicStore
 *              0b10exxx     AtomicLoad
 *              0b110000     AtomicSwap
 *              0b110001     AtomicCompare
 *              e indicates the endianess, and xxx indicates the atomic
 *              operation type.
 *
 * @see         amba_pv_atomic, amba_pv_atomic_subop_t,
 *              amba_pv_atomic_endianness_t
 */
enum amba_pv_atomic_op_t {
    AMBA_PV_NONATOMIC       = 0x00, /**< Non-atomic operation */
    AMBA_PV_ATOMICSTORE     = 0x10, /**< AtomicStore */
    AMBA_PV_ATOMICLOAD      = 0x20, /**< AtomicLoad */
    AMBA_PV_ATOMICSWAP      = 0x30, /**< AtomicSwap */
    AMBA_PV_ATOMICCOMPARE   = 0x31  /**< AtomicCompare */
};

/**
 * @brief     Atomic transaction operation type.
 *
 * The atomic transaction type indicates the operation type of an atomic
 * transaction.
 *
 * The bit representation of this type matches the AXI AWATOP[2:0] AMBA5 signals.
 *
 * @note        Only AtomicStore and AtomicLoad transaction can execute an
 *              atomic operation.
 *
 * @see         amba_pv_atomic, amba_pv_atomic_op_t, amba_pv_atomic_endianness_t
 */
enum amba_pv_atomic_subop_t {
    AMBA_PV_ATOMIC_ADD          = 0x0, /**< Addition */
    AMBA_PV_ATOMIC_BIT_CLEAR    = 0x1, /**< Clean memory bits with the set bits in the sent data  */
    AMBA_PV_ATOMIC_EXCLUSIVE_OR = 0x2, /**< Exclusive OR */
    AMBA_PV_ATOMIC_BIT_SET      = 0x3, /**< Set memory bits with the set bits in the sent data */
    AMBA_PV_ATOMIC_SIGNED_MAX   = 0x4, /**< Maximum of memory value and sent data (assume signed data) */
    AMBA_PV_ATOMIC_SIGNED_MIN   = 0x5, /**< Minimum of memory value and sent data (assume signed data) */
    AMBA_PV_ATOMIC_UNSIGNED_MAX = 0x6, /**< Maximum of memory value and sent data (assume unsigned data) */
    AMBA_PV_ATOMIC_UNSIGNED_MIN = 0x7  /**< Minimum of memory value and sent data (assume unsigned data) */
};

/**
 * @brief     Atomic operation endianness.
 *
 * The atomic operation endianness indicates the endianness of an atomic
 * operation.
 *
 * The bit representation of this type matches the AWATOP[3] AMBA5 signals.
 *
 * @note        Only AtomicStore and AtomicLoad transaction with non-bitwise
 *              operations support big endian.
 *
 * @see         amba_pv_atomic, amba_pv_atomic_op_t, amba_pv_atomic_subop_t
 */
enum amba_pv_atomic_endianness_t {
    AMBA_PV_LITTLE_ENDIAN   = 0x0, /**< little-endian operation */
    AMBA_PV_BIG_ENDIAN      = 0x1  /**< big-endian operation */
};

/**
 * @brief       Provides atomic transaction information used by AMBA AXI buses.
 *              This class contains the information for representing the AXI
 *              AWATOP AMBA5 signals.
 *
 * This class is used as a base class for the AMBA-PV extension type
 * (amba_pv_extension).
 *
 * @see         amba_pv_extension
 */
class amba_pv_atomic {

    public:
    /* Construction */
        amba_pv_atomic() = default;
        explicit amba_pv_atomic(amba_pv_atomic_op_t);
        amba_pv_atomic(amba_pv_atomic_op_t,
                       amba_pv_atomic_subop_t,
                       amba_pv_atomic_endianness_t);

    /* Accessors */

        /* Atomic transaction type */
        void set_atomic_op(amba_pv_atomic_op_t);
        amba_pv_atomic_op_t get_atomic_op() const;

        /* Atomic transaction operation type */
        void set_atomic_subop(amba_pv_atomic_subop_t);
        amba_pv_atomic_subop_t get_atomic_subop() const;

        /* Atomic transaction endianness */
        void set_atomic_endianness(amba_pv_atomic_endianness_t);
        amba_pv_atomic_endianness_t get_atomic_endianness() const;

        /* Resetting */
        void reset();

    /* Helpers */
        bool is_atomic_size_supported(size_t) const;
        bool is_atomic_endianness_valid() const;
        bool is_atomic_request_valid(size_t) const;
        bool is_atomic_subop_valid() const;

  /* Implementation */
    private:
        /* Member variables */
        amba_pv_atomic_op_t m_atomic_op                 = AMBA_PV_NONATOMIC;
        amba_pv_atomic_subop_t m_atomic_subop           = AMBA_PV_ATOMIC_ADD;
        amba_pv_atomic_endianness_t m_atomic_endianness = AMBA_PV_LITTLE_ENDIAN;
};

/* Functions */

/**
 * @brief       Constructor.
 *
 * @param       op atomic transaction type.
 */
inline amba_pv_atomic::amba_pv_atomic(const amba_pv_atomic_op_t op):
    m_atomic_op(op) {
}

/**
 * @brief       Constructor.
 *
 * @param       op atomic transaction type.
 * @param       subop atomic transaction operation type.
 * @param       endianness atomic endianness.
 */
inline amba_pv_atomic::amba_pv_atomic(const amba_pv_atomic_op_t op,
                                      const amba_pv_atomic_subop_t subop,
                                      const amba_pv_atomic_endianness_t endianness):
    m_atomic_op(op), m_atomic_subop(subop), m_atomic_endianness(endianness) {
}

/**
 * @brief       Sets the atomic transaction type.
 *
 * @param       op atomic transaction type.
 *
 * @see         get_atomic_op()
 */
inline void
amba_pv_atomic::set_atomic_op(const amba_pv_atomic_op_t op) {
    m_atomic_op = op;
}

/**
 * @brief       Returns the atomic transaction type.
 *
 * @see         set_atomic_op()
 */
inline amba_pv_atomic_op_t
amba_pv_atomic::get_atomic_op() const {
    return m_atomic_op;
}

/**
 * @brief       Sets the atomic transaction operation type.
 *
 * @param       subop atomic transaction operation type.
 *
 * @see         get_atomic_subop()
 */
inline void
amba_pv_atomic::set_atomic_subop(const amba_pv_atomic_subop_t subop) {
    m_atomic_subop = subop;
}

/**
 * @brief       Returns the atomic transaction operation type.
 *
 * @see         set_atomic_subop()
 */
inline amba_pv_atomic_subop_t
amba_pv_atomic::get_atomic_subop() const {
    return m_atomic_subop;
}

/**
 * @brief       Sets the atomic operation endianness.
 *
 * @param       endianness atomic endianness.
 *
 * @see         get_atomic_endianness()
 */
inline void
amba_pv_atomic::set_atomic_endianness(const amba_pv_atomic_endianness_t endianness) {
    m_atomic_endianness = endianness;
}

/**
 * @brief       Returns the atomic operation endianness.
 *
 * @see         set_atomic_endianness()
 */
inline amba_pv_atomic_endianness_t
amba_pv_atomic::get_atomic_endianness() const {
    return m_atomic_endianness;
}

/**
 * @brief       Resets all members to their default value.
 */
inline void
amba_pv_atomic::reset() {
    *this = {};
}

/**
 * @brief       Checks if the transaction size is supported by the current atomic transaction.
 *
 * AtomicStore, AtomicLoad and AtomicSwap supports sizes of 1, 2, 4 or 8 bytes.
 * AtomicCompare supports sizes of 2, 4, 8, 16 or 32 bytes.
 *
 * @param       size selects the transaction size to be tested.
 *
 * @return      Returns true if the size is supported by the current atomic operation, otherwise false.
 */
inline bool
amba_pv_atomic::is_atomic_size_supported(const size_t size) const {
    switch (m_atomic_op)
    {
    case AMBA_PV_ATOMICSTORE:
    case AMBA_PV_ATOMICLOAD:
    case AMBA_PV_ATOMICSWAP:
        return size == 1 || size == 2 || size == 4 || size == 8;
    case AMBA_PV_ATOMICCOMPARE:
        return size == 2 || size == 4 || size == 8 || size == 16 || size == 32;
    default:
        return false;
    }
}

/**
 * @brief       Check if the big endian is supported by the current atomic
 *              transaction. Big endian is supported only by AtomicStore and
 *              AtomicLoad, with non-bitwise operations.
 */
inline bool
amba_pv_atomic::is_atomic_endianness_valid() const {
    const bool is_supported_op  = (m_atomic_op == AMBA_PV_ATOMICSTORE
                                  || m_atomic_op == AMBA_PV_ATOMICLOAD);
    const bool is_bitwise_subop = AMBA_PV_ATOMIC_BIT_CLEAR <= m_atomic_subop
                                  && m_atomic_subop <= AMBA_PV_ATOMIC_BIT_SET;

    return m_atomic_endianness == AMBA_PV_LITTLE_ENDIAN
           || (is_supported_op && ! is_bitwise_subop);
}

/**
 * @brief       sanity checks the current atomic transaction
 *
 * Burst size and endianness support are checked.
 *
 * @param       size selects the transaction size to be tested.
 *
 * @return      Returns true if size and endianness checks pass, otherwise false.
 *
 * @see         is_atomic_size_supported(), is_atomic_endianness_valid
 */
inline bool
amba_pv_atomic::is_atomic_request_valid(const size_t size) const {
    return is_atomic_size_supported(size)
           && is_atomic_endianness_valid()
           && is_atomic_subop_valid();
}

/**
 * @brief       check if the sub-operation setting is valid
 * 
 * If the operation is set to either AMBA_PV_ATOMICSTORE or
 * AMBA_PV_ATOMICLOAD, then the sub operation can assume any value and the
 * method always returns true. For any other operation the sub operation must
 * be set to AMBA_PV_ATOMIC_ADD. If that is not the case, then the set up is
 * deemed invalid.
 * 
 * @return      True is returned if subop is valid, otherwise false.
 *
 */
inline bool
amba_pv_atomic::is_atomic_subop_valid() const {
    switch (m_atomic_op)
    {
    case AMBA_PV_ATOMICSTORE:
    case AMBA_PV_ATOMICLOAD:
        return true;
    case AMBA_PV_NONATOMIC:
    case AMBA_PV_ATOMICSWAP:
    case AMBA_PV_ATOMICCOMPARE:
        return m_atomic_subop == AMBA_PV_ATOMIC_ADD;
    }

    return false;
}

} /* namespace amba_pv */

#endif /* defined(AMBA_PV_ATOMIC__H) */