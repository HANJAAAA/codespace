/*
 * AMBA-PV: amba_pv_memory.h - AMBA-PV advanced memory model.
 *
 * Copyright 2007-2017 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_MEMORY__H
#define AMBA_PV_MEMORY__H

/**
 * @file        amba_pv_memory.h
 *
 * @brief       AMBA-PV advanced memory model.
 */

/* Includes */
#include "amba_pv_memory_base.h"
#include "amba_pv_heap_allocator.h"
#include <unordered_map>
#include <fstream>
#include <iomanip>
#include <cctype>
#include <malloc.h>

/* Namespaces */

/**
 * @brief       AMBA-PV namespace.
 */
namespace amba_pv {

/* Datatypes */

/**
 * @brief       AMBA-PV advanced memory model.
 *
 * The amba_pv_memory class models an AMBA compatible memory at the PV level
 * and features:
 * - page-based organization with allocate on write policy for optimized
 *   heap usage
 * - a read to non-allocated pages returns the default value
 * - constructor parameter for page size
 * - save and restore.
 *
 * @param       BUSWIDTH bus width in bits as one of 8, 16, 32, 64, 128, 256,
 *              512, or 1024. Defaults to 64.
 */
template<unsigned int BUSWIDTH = 64, class ALLOCATOR=amba_pv_heap_allocator>
class amba_pv_memory:
    public amba_pv_memory_base<BUSWIDTH>,
    public sc_core::sc_module {

    /* Sockets */
    public:

        /**
         * @brief Slave socket.
         */
        amba_pv_slave_socket<BUSWIDTH> amba_pv_s;

    /* Constructor/Destructor */
        amba_pv_memory(const sc_core::sc_module_name &,
                       const sc_dt::uint64 &,
                       unsigned int = 4096);
        amba_pv_memory(const sc_core::sc_module_name &,
                       const sc_dt::uint64 &,
                       unsigned char,
                       unsigned int = 4096);
            /* Deprecated. Use other constructor instead. */
        ~amba_pv_memory();

    /* sc_object overridables */
        virtual const char * kind() const;

    /* Accessors */
        unsigned int get_page_size() const;
        void set_fill_pattern(unsigned char, unsigned char);
        void set_fill_pattern32(unsigned long, unsigned long);


    /* Save/restore */
        void save(const std::string &);
        void save(std::ostream &);
        void restore(const std::string &);
        void restore(std::istream &);

    /* User-layer interface */
    protected:
        virtual amba_pv_resp_t read(int,
                                    const sc_dt::uint64 &,
                                    unsigned char *,
                                    unsigned int,
                                    const amba_pv_control *,
                                    sc_core::sc_time &);
        virtual amba_pv_resp_t write(int,
                                     const sc_dt::uint64 &,
                                     unsigned char *,
                                     unsigned int,
                                     const amba_pv_control *,
                                     unsigned char *,
                                     sc_core::sc_time &);
        virtual bool get_direct_mem_ptr(int,
                                        tlm::tlm_command,
                                        const sc_dt::uint64 &,
                                        const amba_pv_control *,
                                        tlm::tlm_dmi &);
         virtual unsigned int debug_read(int,
                                         const sc_dt::uint64 &,
                                         unsigned char *,
                                         unsigned int,
                                         const amba_pv_control *);
         virtual unsigned int debug_write(int,
                                          const sc_dt::uint64 &,
                                          unsigned char *,
                                          unsigned int,
                                          const amba_pv_control *);

    /* Implementation */
    private:
        typedef std::unordered_map<sc_dt::uint64, unsigned char *> address_lookup_t;

        /* Member variables */
        static constexpr sc_dt::uint64 BLOCK_SIZE = 0x4000000; // 64MiB
        address_lookup_t m_blocks; /* Blocks */

        unsigned int m_page_size; /* Page size (in bytes) */
        unsigned char * m_empty_page;   /* Uninitialized page */
        address_lookup_t m_pages; /* Pages */

        /* Helper methods */
        void allocate_empty_page();
        unsigned char * allocate_new_page(const sc_dt::uint64 & addr);
        void clear();
        bool read_int(const sc_dt::uint64 &, unsigned char *, unsigned int);
        bool write_int(const sc_dt::uint64 &, unsigned char *, unsigned int);
        sc_dt::uint64 get_page_addr(const sc_dt::uint64 & addr) const;
        sc_dt::uint64 get_block_addr(const sc_dt::uint64 & addr) const;
        unsigned int get_offset_in_page(const sc_dt::uint64 & addr) const;
        template<typename T>
        static void save_val(std::ostream &, const T &);
        template<typename T>
        static void restore_val(std::istream &, T &);
};

/* Functions */

/**
 * @brief       Constructor.
 *
 * @param       name memory name.
 * @param       size memory size in bytes. @a size is rounded up to the next
 *              multiple of 4096.
 * @param       page_size memory page size in bytes. Defaults to 4096.
 *              @a page_size is rounded up to the next multiple of 4096.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline
amba_pv_memory<BUSWIDTH, ALLOCATOR>::amba_pv_memory(const sc_core::sc_module_name & name,
                                         const sc_dt::uint64 & size,
                                         unsigned int page_size):
    amba_pv_memory_base<BUSWIDTH>((const char *) name, size),
    sc_core::sc_module(name),
    amba_pv_s("amba_pv_s"),
    m_page_size((page_size + 4095) & ~4095),
    m_empty_page(nullptr){
    allocate_empty_page();

    /* Bindings... */
    amba_pv_s(* this);
}

/**
 * @brief       Constructor.
 *
 * @param       name memory name.
 * @param       size memory size in bytes. @a size is rounded up to the next
 *              multiple of 4096.
 * @param       fill_char fill character used for uninitialized memory.
 * @param       page_size memory page size in bytes. Defaults to 4096.
 *              @a page_size is rounded up to the next multiple of 4096.
 *
 * @note        This constructor is deprecated. Use the other constructor
 *              instead.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline
amba_pv_memory<BUSWIDTH, ALLOCATOR>::amba_pv_memory(const sc_core::sc_module_name & name,
                                         const sc_dt::uint64 & size,
                                         unsigned char fill_char,
                                         unsigned int page_size):
    amba_pv_memory_base<BUSWIDTH>((const char *) name, size),
    sc_core::sc_module(name),
    amba_pv_s("amba_pv_s"),
    m_page_size((page_size + 4095) & ~4095),
    m_empty_page(nullptr){
    static bool warn_constructor = false;

    if (! warn_constructor) {
        warn_constructor = true;
        SC_REPORT_INFO(kind(),
                       "amba_pv_memory(): deprecated, use other constructor "
                       "instead");
    }
    allocate_empty_page();
    std::memset(m_empty_page, fill_char, m_page_size);

    /* Bindings... */
    amba_pv_s(* this);
}

/**
 * @brief       Destructor.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline
amba_pv_memory<BUSWIDTH, ALLOCATOR>::~amba_pv_memory() {
    clear();
    ALLOCATOR::deallocate(this->get_name()+"-empty_page", 0, m_empty_page);
}

/**
 * @brief       Allocates empty page
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
void
amba_pv_memory<BUSWIDTH, ALLOCATOR>::allocate_empty_page() {
    m_empty_page = ALLOCATOR::allocate(this->get_name()+"-empty_page", 0, m_page_size);
}


/**
 * @brief       Allocates a new memory page.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
unsigned char *
amba_pv_memory<BUSWIDTH, ALLOCATOR>::allocate_new_page(const sc_dt::uint64 & page_addr) {

    sc_dt::uint64 block_start_addr = get_block_addr(page_addr);
    sc_dt::uint64 page_block_offset = page_addr - block_start_addr;
    unsigned char * block_pointer;
    address_lookup_t::iterator i;
    if ((i = m_blocks.find(block_start_addr)) != m_blocks.end()) /*Block exists*/ {
          block_pointer = i->second;
    } else {
        // Allocate new block

        sc_dt::uint64 block_allocation_size = this->get_addr_limit() - block_start_addr;
        if (block_allocation_size > BLOCK_SIZE)
            block_allocation_size = BLOCK_SIZE;

        // block_allocation_size should be multiple of m_page_size
        sc_dt::uint64 remainder = block_allocation_size % m_page_size;
        if (remainder > 0)
            block_allocation_size =  block_allocation_size + m_page_size - remainder;

        block_pointer = ALLOCATOR::allocate(this->get_name(), block_start_addr, block_allocation_size);
        m_blocks[block_start_addr]= block_pointer;
    }

    unsigned char * page_pointer =  block_pointer + page_block_offset;
    m_pages[page_addr] = page_pointer;
    std::memcpy(page_pointer, m_empty_page, m_page_size);
    return page_pointer;
}
/**
 * @brief       Returns the kind string of this memory.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline const char *
amba_pv_memory<BUSWIDTH, ALLOCATOR>::kind() const {
    return ("amba_pv_memory");
}

/**
 * @brief       Returns the page size of this memory.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline unsigned int
amba_pv_memory<BUSWIDTH, ALLOCATOR>::get_page_size() const {
    return (m_page_size);
}

/**
 * @brief       Sets the fill pattern used for uninitialized memory.
 *
 * This does not affect any pages that have already been allocated, so ideally
 * this must be called before the first write transaction to this memory.
 *
 * @param       fill_char1 value for odd characters in uninitialized memory.
 * @param       fill_char2 value for even characters in uninitialized memory.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline void
amba_pv_memory<BUSWIDTH, ALLOCATOR>::set_fill_pattern(unsigned char fill_char1,
                                           unsigned char fill_char2) {
    for (unsigned int i = 0; (i < m_page_size); i += 2) {
        m_empty_page[i] = fill_char1;
        m_empty_page[i + 1] = fill_char2;
    }
}

/**
 * @brief       Sets the fill pattern used for uninitialized memory.
 *
 * This does not affect any pages that have already been allocated, so ideally
 * this must be called before the first write transaction to this memory.
 * A little endian memory model is assumed. i.e. the least significant
 * byte of fill_word1 is the first byte in a page of memory.
 *
 * @param       fill_word1 value for odd words in uninitialized memory.
 * @param       fill_word2 value for even words in uninitialized memory.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline void
amba_pv_memory<BUSWIDTH, ALLOCATOR>::set_fill_pattern32(unsigned long fill_word1,
                                             unsigned long fill_word2) {
    for (unsigned int i = 0; (i < m_page_size); i += 8) {
        m_empty_page[i    ] = fill_word1 & 0xFF;
        m_empty_page[i + 1] = (fill_word1 >>  8) & 0xFF;
        m_empty_page[i + 2] = (fill_word1 >> 16) & 0xFF;
        m_empty_page[i + 3] = (fill_word1 >> 24) & 0xFF;
        m_empty_page[i + 4] = fill_word2 & 0xFF;
        m_empty_page[i + 5] = (fill_word2 >>  8) & 0xFF;
        m_empty_page[i + 6] = (fill_word2 >> 16) & 0xFF;
        m_empty_page[i + 7] = (fill_word2 >> 24) & 0xFF;
    }
}

/**
 * @brief       Saves the contents of this memory to the specified @a file.
 *
 * @param       file name of file to save memory contents to.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline void
amba_pv_memory<BUSWIDTH, ALLOCATOR>::save(const std::string & file) {
    std::ofstream ofs;
    
    ofs.open(file.c_str(), std::ios::trunc);
    if (! ofs.is_open()) {
        std::string msg("save(): error opening \"");

        msg += file;
        msg += "\"";
        SC_REPORT_WARNING(kind(), msg.c_str());
    } else {
        save(ofs);
    }
}

/**
 * @brief       Saves the contents of this memory to the specified stream.
 *
 * @param       os stream to save memory contents to.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline void
amba_pv_memory<BUSWIDTH, ALLOCATOR>::save(std::ostream & os) {
    address_lookup_t::iterator i;
    bool exist_p;
    unsigned char * page;

    for (sc_dt::uint64 addr = 0;
         (addr < this->get_addr_limit());
         addr += m_page_size) {
        
        /* Check page existence */
        if ((i = m_pages.find(addr)) != m_pages.end()) {
            exist_p = ((* i).second != nullptr);
        } else {
            exist_p = false;
        }
        if (! exist_p) {
            continue;
        }
   
        /* Save page address */
        save_val(os, addr);
        if (os.fail()) {
            break;
        }

        /* Save page */
        page = (* i).second;
        for (unsigned int j = 0; (j < m_page_size); j += sizeof(unsigned int)) {
            save_val(os, (* reinterpret_cast<unsigned int *>(page + j)));
            if (os.fail()) {
                break;
            }
        }
    }
    if (os.fail()) {
        SC_REPORT_WARNING(kind(), "save(): I/O error");
    }
}

/**
 * @brief       Restore the contents of this memory from the specified @a file.
 *
 * @param       file name of file to restore this memory contents from.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline void
amba_pv_memory<BUSWIDTH, ALLOCATOR>::restore(const std::string & file) {
    std::ifstream ifs;
    
    ifs.open(file.c_str());
    if (! ifs.is_open()) {
        std::string msg("restore(): error opening \"");

        msg += file;
        msg += "\"";
        SC_REPORT_WARNING(kind(), msg.c_str());
    } else {
        restore(ifs);
    }
}

/**
 * @brief       Restore the contents of this memory from the specified stream.
 *
 * @param       is stream to restore this memory contents from.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline void
amba_pv_memory<BUSWIDTH, ALLOCATOR>::restore(std::istream & is) {
    address_lookup_t::iterator i;
    sc_dt::uint64 addr;
    unsigned char * page;
            
    /* Invalidate possible previous DMI pointers to the memory... */
    amba_pv_s->invalidate_direct_mem_ptr(0, sc_dt::uint64(-1));

    /* Clear the memory... */
    clear();
    while (is.good()) {

        /* Restore page address */
        restore_val(is, addr);
        if (! is.good()) {
            break;
        }
        if ((i = m_pages.find(addr)) != m_pages.end()) {
            /* Clear page in case of multiple restore... */
            page = i->second;
            std::memcpy(page, m_empty_page, m_page_size);
        }
        else {
            page = allocate_new_page(addr);
        }

        /* Restore page */
        for (unsigned int j = 0; (j < m_page_size); j += sizeof(unsigned int)) {
            restore_val(is, (* reinterpret_cast<unsigned int *>(page + j)));
            if (! is.good()) {
                if ((j + sizeof(unsigned int)) < m_page_size) {

                    /* Missing values.. */
                    SC_REPORT_WARNING(kind(), "restore(): unexpected EOF");
                    is.setstate(std::istream::failbit);
                }
                break;
            }
        }
    }
    if (is.fail()) {
        SC_REPORT_WARNING(kind(), "restore(): I/O error");
    }
}

/**
 * @brief       Completes a read transaction.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline amba_pv_resp_t
amba_pv_memory<BUSWIDTH, ALLOCATOR>::read(int socket_id,
                               const sc_dt::uint64 & addr,
                               unsigned char * data,
                               unsigned int size,
                               const amba_pv_control * ctrl,
                               sc_core::sc_time & t) {
    if (((addr & ~sc_dt::uint64(size - 1)) + size) > this->get_addr_limit()) {
        return (AMBA_PV_DECERR);
    }
    if (! read_int(addr, data, size)) {
        return (AMBA_PV_SLVERR);
    }
    return (AMBA_PV_OKAY);
}

/**
 * @brief       Completes a write transaction.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline amba_pv_resp_t
amba_pv_memory<BUSWIDTH, ALLOCATOR>::write(int socket_id,
                                const sc_dt::uint64 & addr,
                                unsigned char * data,
                                unsigned int size,
                                const amba_pv_control * ctrl,
                                unsigned char * strb,
                                sc_core::sc_time & t) {
    if (((addr & ~sc_dt::uint64(size - 1)) + size) > this->get_addr_limit()) {
        return (AMBA_PV_DECERR);
    }
    if (strb != nullptr) {
        unsigned char * tmp = new unsigned char[size];
        if (! read_int(addr, tmp, size)) {
            delete [] tmp;
            return (AMBA_PV_SLVERR);
        }
        for (unsigned int i = 0; (i < size); i += 1) {
            if (strb[i] == TLM_BYTE_ENABLED) {
                tmp[i] = data[i];
            }
        }
        if (! write_int(addr, tmp, size)) {
            delete [] tmp;
            return (AMBA_PV_SLVERR);
        }
        delete [] tmp;
    } else if (! write_int(addr, data, size)) {
        return (AMBA_PV_SLVERR);
    }
    return (AMBA_PV_OKAY);
}

/**
 * @brief       Non-intrusive debug read transaction.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline unsigned int
amba_pv_memory<BUSWIDTH, ALLOCATOR>::debug_read(int socket_id,
                                     const sc_dt::uint64& addr,
                                     unsigned char* data,
                                     unsigned int length,
                                     const amba_pv_control* ctrl) {
    unsigned int num_values = 0;
    sc_dt::uint64 addr2 = addr;
    unsigned char * data2 =data;

    while (num_values < length) {
        if (! read_int(addr2 ++, data2 ++, 1)) {
            break;
        }
        num_values ++;
    }
    return (num_values);
}

/**
 * @brief       Non-intrusive debug write transaction.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline unsigned int
amba_pv_memory<BUSWIDTH, ALLOCATOR>::debug_write(int socket_id,
                                      const sc_dt::uint64 & addr,
                                      unsigned char *data,
                                      unsigned int length,
                                      const amba_pv_control *ctrl) {
    unsigned int num_values = 0;
    sc_dt::uint64 addr2 = addr;
    unsigned char * data2 = data;

    while (num_values < length) {
        if (! write_int(addr2 ++, data2 ++, 1)) {
            break;
        }
        num_values ++;
    }
    return (num_values);
}

/**
 * @brief       Requests DMI access to the specified address and returns a
 *              reference to a DMI descriptor.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline bool
amba_pv_memory<BUSWIDTH, ALLOCATOR>::get_direct_mem_ptr(int socket_id,
                                             tlm::tlm_command command,
                                             const sc_dt::uint64 & addr,
                                             const amba_pv_control * ctrl,
                                             tlm::tlm_dmi & dmi_data) {
    address_lookup_t::iterator i;
    unsigned char * page;
    sc_dt::uint64 addr_page = get_page_addr(addr);

    if (addr >= this->get_addr_limit()) {
        return false;
    }
    dmi_data.set_start_address(addr_page);
    dmi_data.set_end_address(std::min(dmi_data.get_start_address() + m_page_size, this->get_addr_limit()) - 1);
    dmi_data.allow_read_write();
    if ((i = m_pages.find(addr_page)) != m_pages.end()) {
        page = (* i).second;
    } else {
        /* We want every DMI request to point to real writable memory. Usually when
           returning DMI from memory, it is because it is doing both reads and writes
           on a page as the common usage pattern.

           The cost of doing a DMI look up is significant enough that in the rare
           cases when a read operation via DMI happens without a write operation
           via DMI, it isn't worth slowing down the more common cases where a read
           operation via DMI happens before a write via DMI operation.

           This is different from what happens if you do an explicit read without
           DMI operation on a page in this component before doing a write operation.
           In those cases the read will be done on an "empty" page and can avoid doing
           an allocation at that point. */
        if (command == tlm::TLM_READ_COMMAND || command == tlm::TLM_WRITE_COMMAND) {
            page = allocate_new_page(addr_page);
        } else {

            /* Unknown command! */
            return false;
        }
    }
    dmi_data.set_dmi_ptr(page);
    return true;
}

/*
 * Clear this memory.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline void
amba_pv_memory<BUSWIDTH, ALLOCATOR>::clear() {
    address_lookup_t::iterator i;

    for (i = m_blocks.begin(); (i != m_blocks.end()); i ++) {
        if ((* i).second != nullptr) {
            ALLOCATOR::deallocate(this->get_name(), (* i).first, (* i).second);
        }
    }
    m_pages.clear();
    m_blocks.clear();
}

/*
 * Internal read.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline bool
amba_pv_memory<BUSWIDTH, ALLOCATOR>::read_int(const sc_dt::uint64 & addr,
                                   unsigned char * data,
                                   unsigned int size) {
    sc_dt::uint64 aa = addr & ~sc_dt::uint64(size - 1); /* Aligned address */

    if ((aa + size) > this->get_addr_limit()) {
        return false;
    }

    sc_dt::uint64 addr_page = get_page_addr(aa);
        /* Page address */
    address_lookup_t::iterator i;
    unsigned char * page = nullptr;

    if ((i = m_pages.find(addr_page)) != m_pages.end()) {
        page = (* i).second;
    } else {
        page = m_empty_page;
    }

    unsigned int offset_page = get_offset_in_page(aa);

    std::memcpy(data, page + offset_page, size);
    return true;
} 

/*
 * Internal write.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline bool
amba_pv_memory<BUSWIDTH, ALLOCATOR>::write_int(const sc_dt::uint64 & addr,
                                    unsigned char * data,
                                    unsigned int size) {
    sc_dt::uint64 aa = addr & ~sc_dt::uint64(size - 1); /* Aligned address */
    
    if ((aa + size) > this->get_addr_limit()) {
        return false;
    }

    sc_dt::uint64 addr_page = get_page_addr(aa);
        /* Page address */
    address_lookup_t::iterator i;
    unsigned char * page;

    if ((i = m_pages.find(addr_page)) != m_pages.end()) {

        /* Page exists... */
        page = (* i).second;
    } else {
        page = allocate_new_page(addr_page);
    }

    unsigned int offset_page = get_offset_in_page(aa);

    std::memcpy(page + offset_page, data, size);
    return true;
}

/*
 * Block address.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline sc_dt::uint64
amba_pv_memory<BUSWIDTH, ALLOCATOR>::get_block_addr(const sc_dt::uint64 & addr) const {
    return addr - (addr % BLOCK_SIZE);
}

/*
 * Page address.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
inline sc_dt::uint64
amba_pv_memory<BUSWIDTH, ALLOCATOR>::get_page_addr(const sc_dt::uint64 & addr) const {
    return addr - (addr % sc_dt::uint64(m_page_size));
}

/*
 * Offset in page.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
unsigned int
amba_pv_memory<BUSWIDTH, ALLOCATOR>::get_offset_in_page(const sc_dt::uint64 & addr) const {
    return static_cast<unsigned int>(addr % sc_dt::uint64(m_page_size));
}

/*
 * Internal save single value.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
template<typename T>
inline void
amba_pv_memory<BUSWIDTH, ALLOCATOR>::save_val(std::ostream & os, const T & v) {
    os << std::hex << std::setfill('0') << std::setw(2 * sizeof(T))
       << std::noshowbase << v << std::endl;
}

/*
 * Internal restore single value.
 */
template<unsigned int BUSWIDTH, class ALLOCATOR>
template<typename T>
inline void
amba_pv_memory<BUSWIDTH, ALLOCATOR>::restore_val(std::istream & is, T & v) {

    /* Skip white spaces and check for EOF first */
    while (std::isspace(is.peek())) {
        is.ignore(1);
    }
    if (is.eof()) {
        return;
    }

    /* Attempt reading value */
    is >> std::hex >> v;

    /* NOTE:    in libstdc++ prior to 4.2.0, istream::operator>> does not set
     *          eofbit, call peek() to ensure eofbit set if necessary */
    is.peek();
}

}   /* namespace amba_pv */

#endif  /* defined(AMBA_PV_MEMORY__H) */
