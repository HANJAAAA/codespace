/*
 * AMBA-PV: amba_pv_simple_probe.h - AMBA-PV simple probe model.
 *
 * Copyright 2007-2009, 2013-2014 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_SIMPLE_PROBE__H
#define AMBA_PV_SIMPLE_PROBE__H

/**
 * @file        amba_pv_simple_probe.h
 *
 * @brief       AMBA-PV simple probe model.
 */

/* Includes */
#include "amba_pv_simple_probe_base.h"

/* Namespaces */

/**
 * @brief       AMBA-PV namespace.
 */
namespace amba_pv {

/* Datatypes */

/**
 * @brief       AMBA-PV simple probe model.
 *
 * The amba_pv_simple_probe model prints the contents of transaction between a master and a slave to @c std::cout, a
 * file, or a stream.
 *
 * @note        If configured for printing transactions, the amba_pv_simple_probe model might have an effect on
 *              performance.
 *
 * @param       BUSWIDTH bus width in bits as one of 8, 16, 32, 64, 128, 256,
 *              512, or 1024. Defaults to 64.
 */
template<unsigned int BUSWIDTH = 64>
class amba_pv_simple_probe:
    public virtual amba_pv_fw_transport_if,
    public virtual amba_pv_bw_transport_if,
    public amba_pv_simple_probe_base<BUSWIDTH> {

    /* Sockets */
    public:

        /**
         * @brief Slave socket.
         */
        amba_pv_slave_socket<BUSWIDTH> amba_pv_s;

        /**
         * @brief Master socket.
         */
        amba_pv_master_socket<BUSWIDTH> amba_pv_m;

    /* Construction */
        explicit amba_pv_simple_probe(const sc_core::sc_module_name &, bool /* trans_verbose */ = true);
        virtual ~amba_pv_simple_probe();

    /* sc_object overridables */
        virtual const char * kind() const;

    /* Forward interface */
    protected:
        virtual void b_transport(int, amba_pv_transaction &, sc_core::sc_time &);
        virtual unsigned int transport_dbg(int, amba_pv_transaction &);
        virtual bool get_direct_mem_ptr(int, amba_pv_transaction &, tlm::tlm_dmi &);

    /* Backward interface */
        virtual void invalidate_direct_mem_ptr(int, sc_dt::uint64, sc_dt::uint64);
};

/* Functions */

/**
 * @brief       Constructor.
 *
 * @param       name probe name.
 * @param       trans_verbose @c true to print transactions (default), @c false otherwise.
 *
 * @see         set_trans_verbose()
 */
template<unsigned int BUSWIDTH>
inline
amba_pv_simple_probe<BUSWIDTH>::amba_pv_simple_probe(const sc_core::sc_module_name & name,
                                                     bool trans_verbose /* = true */):
    amba_pv_simple_probe_base<BUSWIDTH>(name, trans_verbose),
    amba_pv_s("amba_pv_s"),
    amba_pv_m("amba_pv_m") {

    /* Bindings... */
    amba_pv_s(* this);
    amba_pv_m(* this);
}

/**
 * @brief       Destructor.
 */
template<unsigned int BUSWIDTH>
inline
amba_pv_simple_probe<BUSWIDTH>::~amba_pv_simple_probe() {
}

/**
 * @brief       Returns the kind string of this probe.
 */
template<unsigned int BUSWIDTH>
inline const char *
amba_pv_simple_probe<BUSWIDTH>::kind() const  {
    return ("amba_pv_simple_probe");
}

/**
 * @brief       Blocking transport.
 *
 * This version of the method completes the transaction and prints its contents.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe<BUSWIDTH>::b_transport(int socket_id, amba_pv_transaction & trans, sc_core::sc_time & t) {

    /* Print out the transaction attributes */
    this->print_transaction(trans, t);

    /* Extend lifetime of transaction before passing it downstream */
    amba_pv_trans_lock lock(& trans);

    /* Transaction proceeds */
    amba_pv_m->b_transport(trans, t);

    /* Print the response after forwarding */
    this->print_trans_response(trans, t);
}

/**
 * @brief       Debug access to a target.
 *
 * This version of the method forwards this debug access to the slave and prints its contents.
 */
template<unsigned int BUSWIDTH>
inline unsigned int
amba_pv_simple_probe<BUSWIDTH>::transport_dbg(int socket_id, amba_pv_transaction & trans) {

    /* Print the transaction */
    this->print_dbg_trans(trans);

    /* Extend lifetime of transaction before passing it downstream */
    amba_pv_trans_lock lock(& trans);

    /* Debug access proceeds */
    unsigned int ret = amba_pv_m->transport_dbg(trans);

    /* Print dbg transaction response */
    this->print_dbg_trans_resp(trans, ret);
    return (ret);
}

/**
 * @brief       Requests a DMI access based on the specified transaction.
 *
 * This version of the method forwards this DMI access request to the slave and prints its contents.
 */
template<unsigned int BUSWIDTH>
inline bool
amba_pv_simple_probe<BUSWIDTH>::get_direct_mem_ptr(int socket_id,
                                                   amba_pv_transaction & trans,
                                                   tlm::tlm_dmi & dmi_data) {
    /* Print get DMI request details */
    this->print_get_dmi_ptr(trans);

    /* DMI request proceeds... */
    bool ret = amba_pv_m->get_direct_mem_ptr(trans, dmi_data);

    /* Print the response */
    this->print_get_dmi_resp(dmi_data, ret);
    return (ret);
}

/**
 * @brief       Invalidates DMI pointers previously established for the specified DMI region.
 *
 * This version of the method forwards this DMI call to the master after printing its arguments.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe<BUSWIDTH>::invalidate_direct_mem_ptr(int socket_id,
                                                          sc_dt::uint64 start_range,
                                                          sc_dt::uint64 end_range) {

    /* Print invalidate ptr request details */
    this->print_invalidate_ptr(start_range, end_range);

    /* Forward the request */
    amba_pv_s->invalidate_direct_mem_ptr(start_range, end_range);
}

}   /* namespace amba_pv */

#endif  /* defined(AMBA_PV_SIMPLE_PROBE__H) */
