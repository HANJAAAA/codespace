/*
 * AMBA-PV: amba_pv_ace_simple_probe.h - AMBA-PV ACE simple probe model.
 *
 * Copyright 2014 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_ACE_SIMPLE_PROBE__H
#define AMBA_PV_ACE_SIMPLE_PROBE__H

/**
 * @file        amba_pv_ace_simple_probe.h
 *
 * @brief       AMBA-PV ACE simple probe model.
 */

/* Includes */
#include "amba_pv_simple_probe_base.h"

/* Namespaces */

/**
 * @brief       AMBA-PV namespace.
 */
namespace amba_pv {

/* Datatypes */

/**
 * @brief       AMBA-PV ACE simple probe model.
 *
 * The amba_pv_ace_simple_probe model prints the contents of transaction between a master and a slave to @c std::cout, a
 * file, or a stream.
 *
 * @note        If configured for printing transactions, the amba_pv_ace_simple_probe model might have an effect on
 *              performance.
 *
 * @param       BUSWIDTH bus width in bits as one of 8, 16, 32, 64, 128, 256,
 *              512, or 1024. Defaults to 64.
 */
template<unsigned int BUSWIDTH = 64>
class amba_pv_ace_simple_probe:
    public virtual amba_pv_fw_transport_if,
    public virtual amba_pv_ace_bw_transport_if,
    public amba_pv_simple_probe_base<BUSWIDTH> {

    /* Sockets */
    public:

        /**
         * @brief Slave socket.
         */
        amba_pv_ace_slave_socket<BUSWIDTH> amba_pv_s;

        /**
         * @brief Master socket.
         */
        amba_pv_ace_master_socket<BUSWIDTH> amba_pv_m;

    /* Construction */
        explicit amba_pv_ace_simple_probe(const sc_core::sc_module_name &, bool /* trans_verbose */ = true);
        virtual ~amba_pv_ace_simple_probe();

    /* sc_object overridables */
        virtual const char * kind() const;

    /* Forward interface */
    protected:
        virtual void b_transport(int, amba_pv_transaction &, sc_core::sc_time &);
        virtual unsigned int transport_dbg(int, amba_pv_transaction &);
        virtual bool get_direct_mem_ptr(int, amba_pv_transaction &, tlm::tlm_dmi &);

    /* Backward interface */
        virtual void invalidate_direct_mem_ptr(int, sc_dt::uint64, sc_dt::uint64);
        virtual void b_snoop(int, amba_pv_transaction &, sc_core::sc_time &);
        virtual unsigned int snoop_dbg(int, amba_pv_transaction &);

    /* Implementation */
    private:
        void print_snoop(amba_pv_transaction &);
        void print_snoop_details(amba_pv_extension *);
        void print_snoop_response(amba_pv_transaction &);
};

/**
 * @brief       Constructor.
 *
 * @param       name probe name.
 * @param       trans_verbose @c true to print transactions (default), @c false otherwise.
 *
 * @see         set_trans_verbose()
 */
template<unsigned int BUSWIDTH>
inline
amba_pv_ace_simple_probe<BUSWIDTH>::amba_pv_ace_simple_probe(const sc_core::sc_module_name & name,
                                                             bool trans_verbose /* = true */):
    amba_pv_simple_probe_base<BUSWIDTH>(name, trans_verbose),
    amba_pv_s("amba_pv_s"),
    amba_pv_m("amba_pv_m") {

    /* Bindings... */
    amba_pv_s(* this);
    amba_pv_m(* this);
}

/**
 * @brief       Destructor.
 */
template<unsigned int BUSWIDTH>
inline
amba_pv_ace_simple_probe<BUSWIDTH>::~amba_pv_ace_simple_probe() {
}

/**
 * @brief       Returns the kind string of this probe.
 */
template<unsigned int BUSWIDTH>
inline const char *
amba_pv_ace_simple_probe<BUSWIDTH>::kind() const  {
    return ("amba_pv_ace_simple_probe");
}

/**
 * @brief       Blocking transport.
 *
 * This version of the method completes the transaction and prints its contents.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_ace_simple_probe<BUSWIDTH>::b_transport(int socket_id, amba_pv_transaction & trans, sc_core::sc_time & t) {

    /* Print out the transaction attributes */
    this->print_transaction(trans, t);

    /* Extend lifetime of transaction before passing it downstream */
    amba_pv_trans_lock lock(& trans);

    /* Transaction proceeds */
    amba_pv_m->b_transport(trans, t);

    /* Print the response after forwarding */
    this->print_trans_response(trans, t);
}

/**
 * @brief       Debug access to a target.
 *
 * This version of the method forwards this debug access to the slave and prints its contents.
 */
template<unsigned int BUSWIDTH>
inline unsigned int
amba_pv_ace_simple_probe<BUSWIDTH>::transport_dbg(int socket_id, amba_pv_transaction & trans) {

    /* Print the transaction */
    this->print_dbg_trans(trans);

    /* Extend lifetime of transaction before passing it downstream */
    amba_pv_trans_lock lock(& trans);

    /* Debug access proceeds */
    unsigned int ret = amba_pv_m->transport_dbg(trans);

    /* Print dbg transaction response */
    this->print_dbg_trans_resp(trans, ret);
    return (ret);
}

/**
 * @brief       Requests a DMI access based on the specified transaction.
 *
 * This version of the method forwards this DMI access request to the slave and prints its contents.
 */
template<unsigned int BUSWIDTH>
inline bool
amba_pv_ace_simple_probe<BUSWIDTH>::get_direct_mem_ptr(int socket_id,
                                                       amba_pv_transaction & trans,
                                                       tlm::tlm_dmi & dmi_data) {
    /* Print get DMI request details */
    this->print_get_dmi_ptr(trans);

    /* DMI request proceeds... */
    bool ret = amba_pv_m->get_direct_mem_ptr(trans, dmi_data);

    /* Print the response */
    this->print_get_dmi_resp(dmi_data, ret);

    return (ret);
}

/**
 * @brief       Invalidates DMI pointers previously established for the specified DMI region.
 *
 * This version of the method forwards this DMI call to the master after printing its arguments.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_ace_simple_probe<BUSWIDTH>::invalidate_direct_mem_ptr(int socket_id,
                                                              sc_dt::uint64 start_range,
                                                              sc_dt::uint64 end_range) {
    /* Print invalidate ptr request details */
    this->print_invalidate_ptr(start_range, end_range);

    /* Forward the request */
    amba_pv_s->invalidate_direct_mem_ptr(start_range, end_range);
}

/**
 * @brief       Blocking snoop.
 *
 * This version of the method completes the snoop transaction and prints its contents.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_ace_simple_probe<BUSWIDTH>::b_snoop(int socket_id,
                                     amba_pv_transaction& trans,
                                     sc_core::sc_time& t) {
    /* Print the snoop transaction */
    print_snoop(trans);

    /* Transaction proceeds */
    amba_pv_s.b_snoop(trans, t);

    /* Print the snoop response */
    print_snoop_response(trans);
}

/*
 * Prints a snoop transaction information.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_ace_simple_probe<BUSWIDTH>::print_snoop(amba_pv_transaction & trans) {
    amba_pv_dvm * dvm = NULL;
    amba_pv_extension * ex = NULL;

    // Retrieve AMBA-PV extension
    trans.get_extension(ex);
    if (ex == NULL) {
        return;
    }

    if(this->is_transport_verbose())
    {
        this->m_out.str("");
        this->m_out << "snoop(";

        std::string snoop_type = amba_pv_snoop_string(ex->get_snoop());

        if (snoop_type == "AMBA_PV_UNKNOWN") {
            return;
        }
        this->m_out << snoop_type;
        if (snoop_type == "AMBA_PV_DVM_MESSAGE") {
            dvm = (amba_pv_dvm *) ex;
            this->m_out << ", type=" << amba_pv_dvm_message_string(dvm->get_dvm_message_type());
            this->m_out << ", address=" << std::showbase << std::hex << dvm->get_dvm_address();
            if (dvm->is_dvm_vmid_set()) {
                this->m_out << ", VMID=" << dvm->get_dvm_vmid();
            }
            if (dvm->is_dvm_asid_set()) {
                this->m_out << ", ASID=" << dvm->get_dvm_asid();
            }
            if (dvm->is_dvm_virtual_index_set()) {
                this->m_out << ", virtual index=" << dvm->get_dvm_virtual_index();
            }
            this->m_out << ", OS=" << amba_pv_dvm_os_string(dvm->get_dvm_os());
            this->m_out << ", security=" << amba_pv_dvm_security_string(dvm->get_dvm_security());
            this->m_out << ", stage=" << dvm->get_dvm_stage();
        } else {
            this->m_out << ", addr=" << std::showbase << std::hex << trans.get_address();
            if (ex->get_length() > 1) {
                this->m_out << ", len=" << std::noshowbase << std::dec << ex->get_length();
            }
            this->m_out << ", size=" << std::noshowbase << std::dec << ex->get_size();
            if (ex->get_length() > 1) {
                this->m_out << ", burst=" << amba_pv_burst_string(ex->get_burst());
            }
            this->print_control(ex);
        }
        this->m_out << ")";
        SC_REPORT_INFO(this->name(), this->m_out.str().c_str());
    }
}

/*
 * Print the snoop response channels
 * - CRRESP[0] : DataTransfer bit
 * - CRRESP[1] : Error bit
 * - CRRESP[2] : PassDirty bit
 * - CRRESP[3] : IsShared bit
 * - CRRESP[4] : WasUnique bit
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_ace_simple_probe<BUSWIDTH>::print_snoop_response(amba_pv_transaction & trans) {
    amba_pv_extension * ex = NULL;

    trans.get_extension(ex);
    if (ex == NULL) {
        return;
    }
    if(this->is_transport_verbose())
    {
        this->m_out.str("");
        this->m_out << "snoop_resp(";
        this->m_out << "addr=" << std::showbase << std::hex << trans.get_address();
        if (ex->is_snoop_error()) {
            this->m_out << "SNOOP ERROR";
        }
        if (ex->is_snoop_data_transfer()) {
            this->m_out << ", DataTransfer, length="
                        << std::noshowbase << std::dec
                        << trans.get_data_length();
        }
        if (ex->is_pass_dirty()) {
            this->m_out << ", PassDirty";
        }
        if (ex->is_shared()) {
            this->m_out << ", Shared";
        }
        if (ex->is_snoop_was_unique()) {
            this->m_out << ", WasUnique";
        }
        this->m_out << ")";
        SC_REPORT_INFO(this->name(), this->m_out.str().c_str());
    }
}

/**
 * @brief       Debug access to a master.
 *
 * This version of the method forwards this debug access to the master.
 */
template<unsigned int BUSWIDTH>
inline unsigned int
amba_pv_ace_simple_probe<BUSWIDTH>::snoop_dbg(int socket_id,
                                              amba_pv_transaction & trans) {

    /* Debug transaction proceeds */
    return amba_pv_s.snoop_dbg(trans);
}

}   /* namespace amba_pv */

#endif  /* defined(AMBA_PV_ACE_SIMPLE_PROBE__H) */
