/*
 * AMBA-PV: amba_pv_simple_probe_base.h - AMBA-PV simple probe base model.
 *
 * Copyright 2014 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_SIMPLE_PROBE_BASE__H
#define AMBA_PV_SIMPLE_PROBE_BASE__H

/**
 * @file        amba_pv_simple_probe_base.h
 *
 * @brief       AMBA-PV simple probe base model.
 */

/* Includes */
#include <iostream>
#include <sstream>

/* Namespaces */

/**
 * @brief       AMBA-PV namespace.
 */
namespace amba_pv {

/* Datatypes */

/**
 * @brief       AMBA-PV simple probe base model.
 *
 * The amba_pv_simple_probe_base model prints the contents of transaction between a master and a slave to @c std::cout, a
 * file, or a stream.
 *
 * @note        If configured for printing transactions, the amba_pv_simple_probe_base model might have an effect on
 *              performance.
 *
 * @param       BUSWIDTH bus width in bits as one of 8, 16, 32, 64, 128, 256,
 *              512, or 1024. Defaults to 64.
 */
template<unsigned int BUSWIDTH = 64>
class amba_pv_simple_probe_base: public sc_core::sc_module {

    /* Sockets */
    public:

    /* Construction */
        explicit amba_pv_simple_probe_base(const sc_core::sc_module_name &, 
                                           bool /* trans_verbose */ = true);

        virtual ~amba_pv_simple_probe_base();

    /* sc_object overridables */
        virtual const char * kind() const;

    /* Accessors */
        void set_trans_verbose(bool /* verbose */ = true);
        void set_transport_verbose(bool /* verbose */ = true);
        bool is_transport_verbose() const;
        void set_debug_verbose(bool /* verbose */ = true);
        bool is_debug_verbose() const;
        void set_dmi_verbose(bool /* verbose */ = true);
        bool is_dmi_verbose() const;
        void set_data_verbose(bool /* verbose */ = true);
        bool is_data_verbose() const;
        void set_start_time(const sc_core::sc_time &);
        void set_stop_time(const sc_core::sc_time &);

    /* Helpers */
        void print_transaction(amba_pv_transaction &, sc_core::sc_time &);
        void print_trans_response(amba_pv_transaction &, sc_core::sc_time &);
        void print_control(amba_pv_control *);
        void print_data(amba_pv_transaction &);
        void print_dbg_trans(amba_pv_transaction &);
        void print_dbg_trans_resp(amba_pv_transaction &, unsigned int);
        void print_get_dmi_ptr(amba_pv_transaction &);
        void print_get_dmi_resp(tlm::tlm_dmi &, bool);
        void print_invalidate_ptr(sc_dt::uint64, sc_dt::uint64);
        bool is_printing_time() const;

    /* Implementation */
    protected:
        std::ostringstream m_out;

    private:

        /* Member variables */
        bool m_transport_verbose;
        bool m_debug_verbose;
        bool m_dmi_verbose;
        bool m_data_verbose;
        sc_core::sc_time m_start_time;
        sc_core::sc_time m_stop_time;
};

/* Functions */

/**
 * @brief       Constructor.
 *
 * @param       name probe name.
 * @param       trans_verbose @c true to print transactions (default), @c false otherwise.
 *
 * @see         set_trans_verbose()
 */
template<unsigned int BUSWIDTH>
inline
amba_pv_simple_probe_base<BUSWIDTH>::amba_pv_simple_probe_base(const sc_core::sc_module_name & name,
                                                               bool trans_verbose /* = true */):
    sc_core::sc_module(name),
    m_transport_verbose(trans_verbose),
    m_debug_verbose(trans_verbose),
    m_dmi_verbose(trans_verbose),
    m_data_verbose(false),
    m_start_time(sc_core::SC_ZERO_TIME),
    m_stop_time(sc_core::SC_ZERO_TIME) {
}

/**
 * @brief       Destructor.
 */
template<unsigned int BUSWIDTH>
inline
amba_pv_simple_probe_base<BUSWIDTH>::~amba_pv_simple_probe_base() {
}

/**
 * @brief       Returns the kind string of this probe.
 */
template<unsigned int BUSWIDTH>
inline const char *
amba_pv_simple_probe_base<BUSWIDTH>::kind() const  {
    return ("amba_pv_simple_probe_base");
}

/**
 * @brief       Sets verbosity of this probe.
 *
 * If verbosity is set to @c false, no transactions are printed.
 *
 * @param       verbose @c true to print transactions (default), @c false otherwise.
 *
 * @see         set_transport_verbose(), set_debug_verbose(), set_dmi_verbose()
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::set_trans_verbose(bool verbose /* = true */) {
    m_transport_verbose = verbose;
    m_debug_verbose = verbose;
    m_dmi_verbose = verbose;
}

/**
 * @brief       Sets verbosity of this probe with regard to @c b_transport() regular transactions.
 *
 * If verbosity is set to @c false, no regular transactions are printed.
 *
 * @param       verbose @c true to print @c b_transport() regular transactions (default), @c false otherwise.
 *
 * @see         is_transport_verbose()
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::set_transport_verbose(bool verbose /* = true */) {
    m_transport_verbose = verbose;
}

/**
 * @brief       Gets verbosity of this probe with regard to @c b_transport() regular transactions.
 *
 * @return      Returns @c true if regular transactions are printed (default), @c false otherwise.
 *
 * @see         set_transport_verbose()
 */
template<unsigned int BUSWIDTH>
inline bool
amba_pv_simple_probe_base<BUSWIDTH>::is_transport_verbose() const {
    return (m_transport_verbose);
}

/**
 * @brief       Sets verbosity of this probe with regard to @c transport_dbg() debug transactions.
 *
 * If verbosity is set to @c false, no debug transactions are printed.
 *
 * @param       verbose @c true to print debug transactions (default), @c false otherwise.
 *
 * @see         is_debug_verbose()
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::set_debug_verbose(bool verbose /* = true */) {
    m_debug_verbose = verbose;
}

/**
 * @brief       Gets verbosity of this probe with regard to @c transport_dbg() debug transactions.
 *
 * @return      Returns @c true if debug transactions are printed (default), @c false otherwise.
 *
 * @see         set_debug_verbose()
 */
template<unsigned int BUSWIDTH>
inline bool
amba_pv_simple_probe_base<BUSWIDTH>::is_debug_verbose() const {
    return (m_debug_verbose);
}

/**
 * @brief       Sets verbosity of this probe with regard to DMI transactions.
 *
 * If verbosity is set to @c false, no DMI transactions are printed.
 *
 * @param       verbose @c true to print DMI transactions (default), @c false otherwise.
 *
 * @see         is_dmi_verbose()
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::set_dmi_verbose(bool verbose /* = true */) {
    m_dmi_verbose = verbose;
}

/**
 * @brief       Gets verbosity of this probe with regard to DMI transactions.
 *
 * @return      Returns @c true if DMI transactions are printed (default), @c false otherwise.
 *
 * @see         set_dmi_verbose()
 */
template<unsigned int BUSWIDTH>
inline bool
amba_pv_simple_probe_base<BUSWIDTH>::is_dmi_verbose() const {
    return (m_dmi_verbose);
}

/**
 * @brief       Sets verbosity of this probe with regard to transactions data.
 *
 * If verbosity is set to @c false, the data pointer is printed instead.
 *
 * @param       verbose @c true to print transactions data (default), @c false otherwise.
 *
 * @see         is_data_verbose()
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::set_data_verbose(bool verbose /* = true */) {
    m_data_verbose = verbose;
}

/**
 * @brief       Gets verbosity of this probe with regard to transactions data.
 *
 * @return      Returns @c true if transactions data are printed, @c false otherwise.
 *
 * @see         set_data_verbose()
 */
template<unsigned int BUSWIDTH>
inline bool
amba_pv_simple_probe_base<BUSWIDTH>::is_data_verbose() const {
    return (m_data_verbose);
}

/**
 * @brief       Sets start time of this probe.
 *
 * @param       start_time simulation time at which to start printing transactions.
 *
 * @see         set_stop_time()
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::set_start_time(const sc_core::sc_time & start_time) {
    m_start_time = start_time;
}

/**
 * @brief       Sets stop time of this probe.
 *
 * @param       stop_time simulation time at which to stop printing transactions.
 *
 * @see         set_start_time()
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::set_stop_time(const sc_core::sc_time & stop_time) {
    m_stop_time = stop_time;
}

/*
 * Prints the transaction attributes
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::print_transaction(amba_pv_transaction & trans,
                                                       sc_core::sc_time & t)
{
    std::string cmd = "ignore(";
    amba_pv_extension * ex = NULL;

    /* Retrieve AMBA-PV extension */
    trans.get_extension(ex);

    /* Print transaction */
    if (this->is_transport_verbose() && (ex != NULL) && this->is_printing_time()) {
        this->m_out.str("");

        /* Print request */
        if (trans.is_read()) {
            if (ex->get_length() > 1) {
                cmd = "burst_read(";
            } else {
                cmd = "read(";
            }
        } else if (trans.is_write()) {
            if (ex->get_length() > 1) {
                cmd = "burst_write(";
            } else {
                cmd = "write(";
            }
        } else {
            if (ex->get_length() > 1) {
                cmd = "burst_ignore(";
            } else {
                cmd = "ignore(";
            }
        }

        this->m_out << cmd << "addr=" << std::showbase << std::hex << trans.get_address();
        if (trans.is_write()) {
            this->m_out << ", ";
            this->print_data(trans);
        }
        if (ex->get_length() > 1) {
            this->m_out << ", len=" << std::noshowbase << std::dec << ex->get_length();
        }
        this->m_out << ", size=" << std::noshowbase << std::dec << ex->get_size();
        if (ex->get_length() > 1) {
            this->m_out << ", burst=" << amba_pv_burst_string(ex->get_burst());
        }
        this->print_control(ex);
        this->m_out << ", t=" << t << ")";
        SC_REPORT_INFO(this->name(), this->m_out.str().c_str());
    }
}

/*
 * Print transaction response
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::print_trans_response(amba_pv_transaction & trans,
                                                          sc_core::sc_time & t)
{
    std::string cmd = "ignore(";
    amba_pv_extension * ex = NULL;

    /* Retrieve AMBA-PV extension */
    trans.get_extension(ex);

    if (this->is_transport_verbose() && (ex != NULL) && this->is_printing_time()) {
        this->m_out.str("");

        /* Print response */
        if (trans.is_read()) {
            if (ex->get_length() > 1) {
                cmd = "burst_read(";
            } else {
                cmd = "read(";
            }
        } else if (trans.is_write()) {
            if (ex->get_length() > 1) {
                cmd = "burst_write(";
            } else {
                cmd = "write(";
            }
        } else {
            if (ex->get_length() > 1) {
                cmd = "burst_ignore(";
            } else {
                cmd = "ignore(";
            }
        }


        this->m_out << cmd;
        if (trans.is_read()) {
            this->print_data(trans);
            this->m_out << ", ";
        }
        this->m_out << "t=" << t << "): rsp=" << amba_pv_resp_string(ex->get_resp());
        SC_REPORT_INFO(this->name(), this->m_out.str().c_str());
    }
}

/*
 * Print debug transaction attributes
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::print_dbg_trans(amba_pv_transaction & trans)
{
    std::string cmd = "ignore(";
    amba_pv_extension * ex = NULL;

    /* Retrieve AMBA-PV extension */
    trans.get_extension(ex);

    /* Print debug access */
    if (this->is_debug_verbose() && this->is_printing_time()) {
        this->m_out.str("");

        /* Print request */
        if (trans.is_read()) {
                cmd = "debug_read(";
        } else if (trans.is_write()) {
                cmd = "debug_write(";
        } else {
                cmd = "debug_ignore(";
        }

        this->m_out << cmd << "addr=" << std::showbase << std::hex << trans.get_address();
        if (trans.is_write()) {
            this->m_out << ", ";
            this->print_data(trans);
        }
        this->m_out << ", len=" << std::noshowbase << std::dec << trans.get_data_length();
        this->print_control(ex);
        this->m_out << ")";
        SC_REPORT_INFO(this->name(), this->m_out.str().c_str());
    }
}

/*
 * Print debug transaction response
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::print_dbg_trans_resp(amba_pv_transaction & trans, unsigned int ret)
{
    std::string cmd = "ignore(";

    if (this->is_debug_verbose() && this->is_printing_time()) {
        this->m_out.str("");

        /* Print response */
        if (trans.is_read()) {
                cmd = "debug_read(";
        } else if (trans.is_write()) {
                cmd = "debug_write(";
        } else {
                cmd = "debug_ignore(";
        }
        this->m_out << cmd;
        if (trans.is_read()) {
            this->print_data(trans);
        }
        this->m_out << "): " << std::dec << ret;
        SC_REPORT_INFO(this->name(), this->m_out.str().c_str());
    }
}

/*
 * Prints a transaction control information.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::print_control(amba_pv_control * ctrl) {
    if (ctrl == NULL) {
        return;
    }
    m_out << ", id=" << std::showbase << std::hex << ctrl->get_id();
    if (ctrl->is_privileged()) {
        m_out << ", privileged";
    }
    if (ctrl->is_non_secure()) {
        m_out << ", non_secure";
    }
    else if (ctrl->get_physical_address_space() == amba_pv_physical_address_space_t::AMBA_PV_ROOT_PAS)
    {
        m_out << ", root";
    }
    else if (ctrl->get_physical_address_space() == amba_pv_physical_address_space_t::AMBA_PV_REALM_PAS)
    {
        m_out << ", realm";
    }
    if (ctrl->is_instruction()) {
        m_out << ", instruction";
    }
    if (ctrl->is_exclusive()) {
        m_out << ", exclusive";
    }
    if (ctrl->is_locked()) {
        m_out << ", locked";
    }
    if (ctrl->is_bufferable()) {
        m_out << ", bufferable";
    }
    if (ctrl->is_cacheable()) {
        m_out << ", cacheable";
    }
    if (ctrl->is_read_allocate()) {
        m_out << ", read_allocate";
    }
    if (ctrl->is_write_allocate()) {
        m_out << ", write_allocate";
    }
#if defined(AMBA_PV_INCLUDE_ATTRIBUTES)
    if (ctrl->attributes_size() > 0) {
        m_out << ", {";

        std::map<std::string, std::string> attrs(ctrl->attributes_begin(), ctrl->attributes_end());

        for (std::map<std::string, std::string>::const_iterator i = attrs.begin();
             (i != attrs.end());
             i ++) {
            if (i != attrs.begin()) {
                m_out << ", ";
            }
            m_out << i->first << "=" << i->second;
        }
        m_out << "}";
    }
#endif  /* defined(AMBA_PV_INCLUDE_ATTRIBUTES) */
}

/*
 * Dumps a transaction data.
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::print_data(amba_pv_transaction & trans) {
    m_out << "data=";
    if (is_data_verbose()) {
        m_out << "{";
        for (unsigned int i = 0; (i < trans.get_data_length()); i += 1) {
            if (i > 0) {
                m_out << ", ";
            }
            m_out << std::showbase << std::hex << static_cast<unsigned int> (trans.get_data_ptr()[i]);
        }
        m_out << "}";
    } else {
        m_out << static_cast<void *>(trans.get_data_ptr());
    }
}

/*
 * Print details about the getting a DMI pointer
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::print_get_dmi_ptr(amba_pv_transaction & trans)
{
    std::string cmd = "";
    amba_pv_extension * ex = NULL;

    /* Retrieve AMBA-PV extension */
    trans.get_extension(ex);

    /* Print DMI request */
    if (this->is_dmi_verbose() && this->is_printing_time()) {
        this->m_out.str("");

        /* Print request */
        cmd = "get_direct_mem_ptr(";
        if (trans.is_read()) {
            this->m_out << cmd << "read";
        } else if (trans.is_write()) {
            this->m_out << cmd << "write";
        } else {
            this->m_out << cmd << "ignore";
        }
        this->m_out << ", addr=" << std::showbase << std::hex << trans.get_address();
        this->print_control(ex);
        this->m_out << ")";
        SC_REPORT_INFO(this->name(), this->m_out.str().c_str());
    }
}

/*
 * Print response to DMI request
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::print_get_dmi_resp(tlm::tlm_dmi & dmi_data, bool ret)
{
    std::string cmd = "";

    if (this->is_dmi_verbose() && this->is_printing_time()) {
        this->m_out.str("");

        /* Print response */
        cmd = "get_direct_mem_ptr(";
        this->m_out << cmd << "start_address=" << std::showbase << std::hex << dmi_data.get_start_address()
              << ", end_address=" << std::showbase << std::hex << dmi_data.get_end_address() << ", access={";
        if (dmi_data.is_read_allowed()) {
            this->m_out << "read";
        }
        if (dmi_data.is_write_allowed()) {
            if (dmi_data.is_read_allowed()) {
                this->m_out << ", ";
            }
            this->m_out << "write";
        }
        this->m_out << "}): " << (ret? "true": "false");
        SC_REPORT_INFO(this->name(), this->m_out.str().c_str());
    }
}

/*
 * Print invalidate DMI pointer details
 */
template<unsigned int BUSWIDTH>
inline void
amba_pv_simple_probe_base<BUSWIDTH>::print_invalidate_ptr(sc_dt::uint64 start_range,
                                                   sc_dt::uint64 end_range)
{
     if (this->is_dmi_verbose() && this->is_printing_time()) {
        this->m_out.str("");
        this->m_out << "invalidate_direct_mem_ptr(start_range="
                    << std::showbase << std::hex << start_range
                    << ", end_range=" << std::showbase << std::hex
                    << end_range << ")";

        SC_REPORT_INFO(this->name(), this->m_out.str().c_str());
    }
}

/*
 * Checks whether the current simulation time is in between start and stop times.
 */
template<unsigned int BUSWIDTH>
inline bool
amba_pv_simple_probe_base<BUSWIDTH>::is_printing_time() const {
    return ((sc_core::sc_time_stamp() >= this->m_start_time)
            && ((this->m_stop_time <= this->m_start_time)
                || (sc_core::sc_time_stamp() <= this->m_stop_time)));
}

}   /* namespace amba_pv */

#endif  /* defined(AMBA_PV_SIMPLE_PROBE_BASE__H) */
