/*
 * AMBA-PV: amba_pv_heap_allocator.h - AMBA-PV heap memory allocator.
 *
 * Copyright 2017 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_HEAP_ALLOCATOR__H
#define AMBA_PV_HEAP_ALLOCATOR__H

/**
 * @file        amba_pv_heap_allocator.h
 *
 * @brief       heap memory allocator.
 */

/* Namespaces */

/**
 * @brief       AMBA-PV namespace.
 */
namespace amba_pv {

/* Datatypes */

/* Heap Allocator */

/**
 * @brief       AMBA-PV heap memory allocator.
 *
 * The amba_pv_heap_allocator class models a simple allocator and features:
 * - allocate function which allocates the memory needed. Allocated memory will be
 *   host page size aligned
 * - deallocate function which frees the memory when no longer required
 *
 */

class amba_pv_heap_allocator
{
public:
    static uint8_t* allocate(const std::string& name, const sc_dt::uint64 & addr, const std::size_t& size);
    static void deallocate(const std::string& name, const sc_dt::uint64 & addr, unsigned char* data);
};

/**
 * @brief       Internal - allocate memory aligned to host memory page size
 *
 * @param       size in bytes of allocation required
 */
inline uint8_t*
amba_pv_heap_allocator::allocate(const std::string& /*name*/, const sc_dt::uint64 & /*addr*/, const std::size_t& size) {
    const uintptr_t page_size_4k = 1<<12; // 4k host pages

    /* C11 aligned_alloc() would be a better alternative when supported */
#if defined(_WIN32)
    return reinterpret_cast<uint8_t*>(_aligned_malloc(size, page_size_4k));
#elif defined(__unix)
    void *ptr;
    if (posix_memalign(&ptr, page_size_4k, size) != 0)
    {
        ptr = 0;
    }
    return reinterpret_cast<uint8_t*>(ptr);
#else
#error "Unsupported OS"
#endif
}

/**
 * @brief       Internal - free host page aligned memory allocated by allocate()
 *
 * @param       pointer returned by previous call to allocate()
 */
inline void
amba_pv_heap_allocator::deallocate(const std::string& /*name*/, const sc_dt::uint64 & /*addr*/, uint8_t* ptr) {
#if defined(_WIN32)
    _aligned_free(ptr);
#elif defined(__unix)
    free(ptr);
#else
#error "Unsupported OS"
#endif
}

}   /* namespace amba_pv */

#endif  /* defined(AMBA_PV_HEAP_ALLOCATOR__H) */
