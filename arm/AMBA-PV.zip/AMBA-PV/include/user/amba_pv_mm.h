/*
 * AMBA-PV: amba_pv_mm.h - AMBA-PV transaction memory manager classes.
 *
 * Copyright 2013-2014 ARM Limited.
 * All rights reserved.
 */

#ifndef AMBA_PV_MM__H
#define AMBA_PV_MM__H

/**
 * @file        amba_pv_mm.h
 *
 * @brief       AMBA-PV transaction memory manager classes.
 */

/* Includes */
#include <queue>
#include <algorithm>

/* Namespaces */

/**
 * @brief       AMBA-PV namespace.
 */
namespace amba_pv {

/* Datatypes */

/**
 * @brief       AMBA-PV transaction pool.
 *
 * This class implements the @c tlm::tlm_mm_interface and provides a memory
 * pool from which transaction can be (de)allocated.
 *
 * @note        amba_pv_trans_pool is not an @c sc_module.
 */
class amba_pv_trans_pool:
    public virtual tlm::tlm_mm_interface {

    public:
        /**
        * @brief       AMBA-PV transaction allocator.
        *
        * This class implements the default allocator for the transactions in
        * the pool.
        * Derived classes could implement their own memory management while the
        * transactions are still handled by the pool.
        */
        class transaction_allocator {
        public:

            /**
             *  Convenience definitions of pointers and references to AMBA-PV
             *  transaction.
             */
            typedef amba_pv_transaction * pointer;
            typedef const amba_pv_transaction * const_pointer;
            typedef amba_pv_transaction & reference;
            typedef const amba_pv_transaction & const_reference;

            /**
             * @brief       Destructor.
             *
             * Forces derived classes to have a virtual destructor for safety.
             */
            virtual ~transaction_allocator() {}

            /**
             * @brief       Factory method.
             *
             * Allocates and returns a new AMBA-PV transaction.
             *
             * @param       pool pointer to pool owning new transaction.
             */
            virtual pointer allocate(amba_pv_trans_pool * pool) {
                pointer trans = NULL;

                trans = new amba_pv_transaction(pool);
                trans->set_extension(new amba_pv_extension());
                return trans;
            }

            /**
             * @brief       Factory method.
             *
             * Allocates and returns a new AMBA-PV transaction.
             * It will also allocate a new associated AMBA-PV extension.
             *
             * @param       pool pointer to pool owning new transaction.
             * @param       length transaction burst length as in [1-256].
             * @param       size transaction burst size in bytes as one of
             *              [1, 2, 4, 8, 16, 32, 64, 128].
             * @param       ctrl optional AMBA&nbsp;4 control information (set
             *              to @c NULL if unused).
             * @param       burst transaction burst type as one of
             *              @c AMBA_PV_INCR, @c AMBA_PV_FIXED, @c AMBA_PV_WRAP.
             */
            virtual pointer allocate(amba_pv_trans_pool * pool,
                                     unsigned int length,
                                     unsigned int size,
                                     const amba_pv_control * ctrl,
                                     amba_pv_burst_t burst) {
                pointer trans = NULL;

                trans = new amba_pv_transaction(pool);
                trans->set_extension(new amba_pv_extension(length, size, ctrl, burst));
                return trans;
            }

            /**
             * @brief       Deallocates an AMBA-PV transaction.
             *
             * @param       trans pointer to transaction to be deleted.
             */
            virtual void deallocate(pointer trans) {
                delete trans;
            }
        };


    /* Constructor */
        explicit amba_pv_trans_pool(size_t = 0, transaction_allocator * = NULL);
        ~amba_pv_trans_pool();

    /* Accessors */
        amba_pv_transaction * allocate();
        amba_pv_transaction * allocate(unsigned int, const amba_pv_control *);
        amba_pv_transaction * allocate(unsigned int,
                                       unsigned int,
                                       const amba_pv_control *,
                                       amba_pv_burst_t);
        bool empty() const;
        size_t size() const;
        void reserve(size_t);

    /* Implementation */
    private:
        std::queue<amba_pv_transaction *> m_pool; /* Transaction pool */
        transaction_allocator * m_allocator;
        bool m_own_allocator;

        /* TLM memory manager interface */
        virtual void free(amba_pv_transaction *);

        /* Copying - disabled */
        amba_pv_trans_pool(const amba_pv_trans_pool &);
        amba_pv_trans_pool & operator =(const amba_pv_trans_pool &);
};

/**
 * @brief       AMBA-PV transaction smart pointer.
 *
 * amba_pv_trans_ptr is a smart pointer that retains sole ownership of a
 * transaction through a pointer and releases that transaction when the
 * amba_pv_trans_ptr goes out of scope.
 * 
 * @note        No two amba_pv_trans_ptr instances can manage the same
 *              transaction.
 *
 * @note        amba_pv_trans_ptr is not an @c sc_module.
 */
class amba_pv_trans_ptr {

    /* Constructor */
    public:
        explicit amba_pv_trans_ptr(amba_pv_transaction * = NULL);
        ~amba_pv_trans_ptr();

    /* Accessors */
        amba_pv_transaction * release();
        void reset(amba_pv_transaction * = NULL);
        void swap(amba_pv_trans_ptr &);
        amba_pv_transaction * get() const;
        operator bool() const;
        amba_pv_transaction & operator *() const;
        amba_pv_transaction * operator ->() const;

    /* Implementation */
    private:
        amba_pv_transaction * m_trans; /* Managed transaction */

        /* Copying - disabled */
        amba_pv_trans_ptr(const amba_pv_trans_ptr &);
        amba_pv_trans_ptr & operator =(const amba_pv_trans_ptr &);
};

/**
 * @brief       AMBA-PV transaction lock wrapper.
 *
 * amba_pv_trans_lock class allows for controlling transaction for a block of
 * code and ensuring that it is released when the block is exited, whether by
 * running off the end, by using a control flow statement such as @c break or
 * @c return, or by throwing an exception.
 * 
 * @note        No two amba_pv_trans_lock instances can control the same
 *              transaction.
 *
 * @note        amba_pv_trans_lock is not an @c sc_module.
 */
class amba_pv_trans_lock {

    /* Constructor */
    public:
        explicit amba_pv_trans_lock(amba_pv_transaction *, bool = true);
        ~amba_pv_trans_lock();

    /* Accessors */
        void acquire();
        void release();
        bool is_acquired() const;
        amba_pv_transaction * get_trans() const;
    /* Implementation */
    private:
        amba_pv_transaction * m_trans; /* Controlled transaction */

        /* Copying - disabled */
        amba_pv_trans_lock(const amba_pv_trans_lock &);
        amba_pv_trans_lock & operator =(const amba_pv_trans_lock &);
};

/* Functions - amba_pv_trans_pool */

/**
 * @brief       Frees a previously allocated AMBA-PV transaction.
 */
inline void
amba_pv_trans_pool::reserve(size_t n) {
    while (m_pool.size() < n) {
        transaction_allocator::pointer trans = NULL;

        trans = m_allocator->allocate(this);
        m_pool.push(trans);
    }
}

/**
 * @brief       Constructor.
 *
 * @param       n number of transactions initially allocated in the pool
 * @param       alloc transaction allocator for this pool.
 */
inline
amba_pv_trans_pool::amba_pv_trans_pool(size_t n /* = 0 */,
                                       transaction_allocator * alloc /* = NULL */):
    m_allocator(alloc),
    m_own_allocator(alloc? false: true) {
    if (m_own_allocator) {
        m_allocator = new transaction_allocator;
    }
    reserve(n);
}

/**
 * @brief       Destructor.
 */
inline
amba_pv_trans_pool::~amba_pv_trans_pool() {
    while (! m_pool.empty()) {
        transaction_allocator::pointer trans = m_pool.front();

        sc_assert(trans->get_ref_count() == 0);
        m_allocator->deallocate(trans);
        m_pool.pop();
    }
    if (m_own_allocator) {
        delete m_allocator;
    }
}

/**
 * @brief       Allocates and returns a new AMBA-PV transaction.
 *
 * allocate() will also (re)set the associated AMBA-PV extension.
 *
 * @param       length transaction burst length as in [1-256].
 * @param       size transaction burst size in bytes as one of [1, 2, 4, 8, 16,
 *              32, 64, 128].
 * @param       ctrl optional AMBA&nbsp;4 control information (set to @c NULL if
 *              unused).
 * @param       burst transaction burst type as one of @c AMBA_PV_INCR,
 *              @c AMBA_PV_FIXED, @c AMBA_PV_WRAP.
 */
inline amba_pv_transaction *
amba_pv_trans_pool::allocate(unsigned int length,
                             unsigned int size,
                             const amba_pv_control * ctrl,
                             amba_pv_burst_t burst)  {
    transaction_allocator::pointer trans = NULL;

    if (m_pool.empty()) {
        trans = m_allocator->allocate(this, length, size, ctrl, burst);
    } else {
        trans = m_pool.front();
        m_pool.pop();
        trans->get_extension<amba_pv_extension>()->reset(length, size, ctrl, burst);
    }
    return (trans);
}

/**
 * @brief       Allocates and returns a new AMBA-PV transaction with associated
 *              AMBA-PV extension.
 *
 * allocate() will also (re)set the associated AMBA-PV extension.
 */
inline amba_pv_transaction *
amba_pv_trans_pool::allocate()  {
    return (allocate(1, 8, NULL, AMBA_PV_INCR));
}

/**
 * @brief       Allocates and returns a new AMBA-PV transaction with associated
 *              AMBA-PV extension.
 *
 * allocate() will also (re)set the associated AMBA-PV extension.
 *
 * @param       size transaction size in bytes as one of [1, 2, 4, 8, 16, 32,
 *              64, 128].
 * @param       ctrl optional AMBA&nbsp;4 control information (set to @c NULL if
 *              unused).
 */
inline amba_pv_transaction *
amba_pv_trans_pool::allocate(unsigned int size,
                             const amba_pv_control * ctrl) {
    return (allocate(1, size, ctrl, AMBA_PV_INCR));
}

/**
 * @brief       Returns whether this manager's pool is empty (i.e. whether its
 *              size is 0).
 */
inline bool
amba_pv_trans_pool::empty() const  {
    return (m_pool.empty());
}

/**
 * @brief       Returns the number of transactions in this manager's pool.
 */
inline size_t
amba_pv_trans_pool::size() const  {
    return (m_pool.size());
}

/*
 * Frees a previsouly allocated AMBA-PV transaction.
 */
inline void
amba_pv_trans_pool::free(amba_pv_transaction * trans) {
    if (trans != NULL) {
        sc_assert(trans->get_extension<amba_pv_extension>() != NULL);
        trans->reset();

        /* NOTE:    reset() does not reset all the transaction attributes... */
        trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
        trans->set_dmi_allowed(false);
        m_pool.push(trans);
    }
}

/* Functions - amba_pv_trans_ptr */

/**
 * @brief       Constructor.
 *
 * @param       trans transaction pointer to manage.
 */
inline
amba_pv_trans_ptr::amba_pv_trans_ptr(amba_pv_transaction * trans /* = NULL */):
    m_trans(trans) {
    if (m_trans != NULL) {
        m_trans->acquire();
    }
}

/**
 * @brief       Destructor.
 */
inline
amba_pv_trans_ptr::~amba_pv_trans_ptr() {
    if (m_trans != NULL) {
        m_trans->release();
    }
}

/**
 * @brief       Returns a pointer to the managed transaction and releases the
 *              ownership.
 */
inline amba_pv_transaction *
amba_pv_trans_ptr::release() {
    amba_pv_transaction * trans = m_trans;

    m_trans = NULL;
    return (trans);
}

/**
 * @brief       Replaces the managed transaction.
 *
 * @param       trans pointer to new transaction to manage.
 */
inline void
amba_pv_trans_ptr::reset(amba_pv_transaction * trans /* = NULL */) {
    amba_pv_transaction * old_trans = m_trans;

    m_trans = trans;
    if (m_trans != NULL) {
        m_trans->acquire();
    }
    if (old_trans != NULL) {
        old_trans->release();
    }
}

/**
 * @brief       Swaps the managed transactions.
 *
 * @param       ptr transaction smart pointer to swap managed transactions with.
 */
inline void
amba_pv_trans_ptr::swap(amba_pv_trans_ptr & ptr) {
    std::swap(m_trans, ptr.m_trans);
}

/*
 * @brief       Returns a pointer to the managed transaction.
 */
inline amba_pv_transaction *
amba_pv_trans_ptr::get() const {
    return (m_trans);
}

/*
 * @brief       Checks whether there is an associated managed transaction.
 */
inline
amba_pv_trans_ptr::operator bool() const {
    return (m_trans != NULL);
}

/*
 * @brief       Returns a reference to the managed transaction owned by this
 *              pointer.
 */
inline amba_pv_transaction &
amba_pv_trans_ptr::operator *() const {
    if (m_trans == NULL) {
        SC_REPORT_ERROR("amba_pv_trans_ptr",
                        "operator *(): no transaction owned");
    }
    return (* m_trans);
}

/*
 * @brief       Returns a pointer to the managed transaction.
 */
inline amba_pv_transaction *
amba_pv_trans_ptr::operator ->() const {
    return (m_trans);
}

/*
 * @brief       Compares the value of two transaction smart pointers.
 */
inline bool
operator ==(const amba_pv_trans_ptr & x, const amba_pv_trans_ptr & y) {
    return (x.get() == y.get());
}

/*
 * @brief       Compares the value of two transaction smart pointers.
 */
inline bool
operator !=(const amba_pv_trans_ptr & x, const amba_pv_trans_ptr & y) {
    return (! (x == y));
}

/*
 * @brief       Compares the value of two transaction smart pointers.
 */
inline bool
operator <(const amba_pv_trans_ptr & x, const amba_pv_trans_ptr & y) {
    return (x.get() < y.get());
}

/*
 * @brief       Compares the value of two transaction smart pointers.
 */
inline bool
operator <=(const amba_pv_trans_ptr & x, const amba_pv_trans_ptr & y) {
    return (! (y < x));
}

/*
 * @brief       Compares the value of two transaction smart pointers.
 */
inline bool
operator >(const amba_pv_trans_ptr & x, const amba_pv_trans_ptr & y) {
    return (y < x);
}

/*
 * @brief       Compares the value of two transaction smart pointers.
 */
inline bool
operator >=(const amba_pv_trans_ptr & x, const amba_pv_trans_ptr & y) {
    return (! (x < y));
}

/* Functions - amba_pv_trans_lock */

/**
 * @brief       Constructor.
 *
 * @param       trans transaction pointer to control.
 * @param       acquire @c true to acquire onwership of the transaction, @c false otherwise.
 */
inline
amba_pv_trans_lock::amba_pv_trans_lock(amba_pv_transaction * trans, bool acquire /* = true */):
    m_trans(trans) {
    if ((m_trans != NULL) && m_trans->has_mm() && acquire) {
        m_trans->acquire();
    }
}

/**
 * @brief       Destructor.
 */
inline
amba_pv_trans_lock::~amba_pv_trans_lock() {
    if ((m_trans != NULL) && m_trans->has_mm() && is_acquired()) {
        m_trans->release();
    }
}

/**
 * @brief       Acquires the ownership of the controlled transaction.
 */
inline void
amba_pv_trans_lock::acquire() {
    if ((m_trans != NULL) && m_trans->has_mm() && (! is_acquired())) {
        m_trans->acquire();
    }
}

/**
 * @brief       Releases the ownership of the controlled transaction.
 */
inline void
amba_pv_trans_lock::release() {
    if ((m_trans != NULL) && m_trans->has_mm() && is_acquired()) {
        m_trans->release();
    }
}

/*
 * @brief       Checks whether the controlled transaction ownership has been acquired.
 */
inline bool
amba_pv_trans_lock::is_acquired() const {
    if (m_trans == NULL) {
        return false;
    }
    return (m_trans->get_ref_count());
}

/*
 * @brief       Returns a pointer to the controlled transaction.
 */
inline amba_pv_transaction *
amba_pv_trans_lock::get_trans() const {
    return (m_trans);
}

}   /* namespace amba_pv */

#endif  /* defined(AMBA_PV_MM__H) */
