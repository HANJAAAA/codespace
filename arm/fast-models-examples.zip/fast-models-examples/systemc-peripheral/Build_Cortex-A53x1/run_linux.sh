#!/bin/sh
#
# Copyright 2019 ARM Limited.
# All rights reserved.
#

./system/systemc-peripheral-example.x -a ./software/hello-peripheral.axf $*
