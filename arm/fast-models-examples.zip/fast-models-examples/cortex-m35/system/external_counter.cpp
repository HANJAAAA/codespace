/*
 * Copyright (c) 2022 Arm Limited. All rights reserved.
 */
#include "external_counter.h"

