Project files for Microsoft Visual C++ 2005 (8.0) are provided in the 
subdidrectory containing each of these examples.

Each project file has the correct settings to build the example in either
Debug or Release modes.

The project files assume an environment variable name SYSTEMC exists and 
contains the path to the mscv80 subdirectory that is part of the SystemC 
installation (e.g. C:\systemc-2.3.0\msvc80).