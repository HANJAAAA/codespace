Project files for Microsoft Visual C++ version 8.0 are provided in the
subdidrectory containing each of these examples.

Each project file has the correct settings to build the example in either
Debug or Release modes.

The project files assume environment variables named SYSTEMC and SCV exist and 
contain the paths to the MSVC subdirectories that are part of the SystemC and
SCV installations respectively (e.g. C:\apps\systemc-2.3.0\msvc80 and
C:\apps\scv-2.0.0\msvc80).
