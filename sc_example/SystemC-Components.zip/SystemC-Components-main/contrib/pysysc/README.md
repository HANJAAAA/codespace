#PySysC SCC

SCC is the SystemC components productivity library.
PySysC package makes SystemC usable from Python.
The PySysC SCC Python module enables SCC usage in PySysC context.